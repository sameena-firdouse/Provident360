# Provident360 - privacy and data handling (demo build)

Data collected for identity checks: legal name, date of birth, PAN (optional). Aadhaar is NOT collected.
- PAN is encrypted before storage (Fernet). Matching uses a keyed hash, so PAN is never decrypted or sent to a browser; only "XXXXXX" + last 4 characters is shown.
- The key comes from PROVIDENT360_KEY, or is created in .secrets/key on first run. Never commit it (see .gitignore). Losing it makes stored PAN unreadable; back it up separately from database backups.
- Notifications, audit entries and error messages contain field names only, never values. Case notes reject PAN/Aadhaar-looking numbers.
- No endpoint reveals a full identifier. If a reveal is ever required, add a dedicated, permission-checked endpoint that writes to audit_log first.

Retention and deletion (policy to apply in deployment)
- Identity details: kept while the account is active. Employees can delete their own (Identity Verification page); employers can delete records they entered.
- Resolved cases and audit entries: keep 12 months, then delete (needs a scheduled job - not included).
- Backups and exports: encrypt, restrict access, delete on the same schedule. Use synthetic data in development and demos only.

Not yet built: document uploads (store outside static/, serve only through an authenticated endpoint with short-lived links), admin/support roles, encryption of existing PF Member ID columns, rate limiting, HTTPS (set PROVIDENT360_HTTPS=1 behind an HTTPS proxy so cookies are Secure).

Issue Resolution & Contact Assistant
- Tracked issues, notes and status history are stored in the local database (issues, issue_notes, issue_events) and are visible only to the employee who created them; employer accounts are denied.
- Descriptions, notes and references reject PAN/Aadhaar-like and 9-18 digit numbers. Message templates use only the employee's own records, show only the last 4 characters of a PF Member ID, and use [placeholders] for anything unknown.
- Notifications are in-app only (no email/SMS). Status changes and issue creation are written to audit_log without field values.
- Demo contacts are fictional example.com personas, not verified and not EPFO contacts.

## Image uploads (screenshots, documents)
- Images are scanned on the server, in memory, before any write. A screenshot that appears to contain an OTP / verification code, or Aadhaar, PAN, UAN, bank, card or PIN/password details, is rejected and not stored. OCR text, detected values, thumbnails and previews of rejected images are never kept.
- Accepted images are re-encoded (metadata such as EXIF/GPS removed) and stored encrypted with the same key as PAN, in a private directory that is not served directly. Only the owner can view or delete them.
- Audit entries for uploads hold only: who, which route, outcome, reason code and category name. No file names are stored.