Provident360 (demo)
  pip install cryptography
  python app.py        -> http://localhost:8000
  python test_app.py   -> 26 tests
See PRIVACY.md

Issue Resolution & Contact Assistant: sign in as an employee -> "Issue Assistant" (#/issues).
  Optional: PROVIDENT360_GRIEVANCE_URL (https only; default https://epfigms.gov.in/)
  Contacts are FICTIONAL demo personas (example.com). Saving an issue stores it locally only; nothing is emailed or filed.