import os, tempfile, unittest
os.environ["PROVIDENT360_DB"] = os.path.join(tempfile.mkdtemp(), "t.db")
from cryptography.fernet import Fernet
os.environ["PROVIDENT360_KEY"] = Fernet.generate_key().decode()
import app

def call(method, path, body=None, who=None):
    c = app.db()
    try:
        cookie = ""
        if who:
            _, _, h = app.api(c, "POST", "/api/login", {"email": who, "password": "demo1234"}); cookie = h["Set-Cookie"].split(";")[0]
        try: return app.api(c, method, path, body or {}, cookie)[:2]
        except app.Bad as e: return e.code, {"error": str(e)}
    finally: c.close()

ASHA, SUN, LAKE = "asha@demo.test", "hr@sunrise.demo.test", "hr@lakeview.demo.test"
def rows(): return {(r["employer_name"][:3], r["month"]): r for r in call("GET", "/api/employee/dashboard", who=ASHA)[1]["rows"]}

class T(unittest.TestCase):
    @classmethod
    def setUpClass(cls): app.init()
    def test_1_matching_and_status(self):
        r = rows()[("Sun", "2024-01")]
        self.assertEqual((r["status_label"], r["classification"], r["ecr_ref"]), ("Passbook credit recorded", "No discrepancy detected", "ECR-DEMO-0001"))
        self.assertTrue(r["pf_member_id"].startswith("••••"))
    def test_2_payment_without_passbook(self):
        r = rows()[("Sun", "2024-02")]
        self.assertEqual(r["classification"], "Possible timing difference"); self.assertIn("Passbook credit not verified", r["explanation"])
    def test_3_overlap_needs_review(self):
        for k in (("Sun", "2024-03"), ("Lak", "2024-03")):
            self.assertEqual((rows()[k]["classification"], rows()[k]["status_label"]), ("Potential overlap", "Needs review"))
    def test_4_missing_then_matched_after_employer_saves(self):
        r = rows()[("Lak", "2024-04")]; self.assertEqual(r["classification"], "Missing record")
        self.assertIn("No employer ECR record matched", r["explanation"])
        self.assertEqual(call("POST", "/api/employer/records", dict(employee_name="Asha Demo", pf_member_id=app.PF_B, month="2024-04", pf_wages=40000,
            emp_epf=1800, ecr_status="Submitted", ecr_ref="ECR-NEW", ecr_date="2024-05-10", pay_status="Unknown"), LAKE)[0], 200)
        r = rows()[("Lak", "2024-04")]; self.assertEqual((r["ecr_ref"], r["status_label"]), ("ECR-NEW", "Submitted (employer-reported)"))
    def test_5_duplicates_blocked(self):
        d = dict(employee_name="X", pf_member_id=app.PF_A, month="2024-01", ecr_status="Submitted")
        self.assertEqual(call("POST", "/api/employer/records", d, SUN)[0], 409)
        self.assertEqual(call("POST", "/api/employee/employments", dict(employer_name="Z", pf_member_id=app.PF_A), ASHA)[0], 409)
    def test_6_access_control(self):
        self.assertEqual(call("GET", "/api/employee/dashboard")[0], 401)
        self.assertEqual(call("GET", "/api/employer/dashboard", who=ASHA)[0], 403)
        self.assertEqual(call("GET", "/api/employee/dashboard", who=SUN)[0], 403)
        rid = call("GET", "/api/employer/dashboard", who=SUN)[1]["records"][0]["id"]
        self.assertEqual(call("POST", "/api/employer/records", dict(id=rid, employee_name="Hack", pf_member_id=app.PF_A, month="2024-01", ecr_status="Submitted"), LAKE)[0], 404)
        self.assertEqual(call("GET", f"/api/employer/history/{rid}", who=LAKE)[0], 404)
        self.assertTrue(all(r["employee_name"] and r["pf_member_id"] == app.PF_B for r in call("GET", "/api/employer/dashboard", who=LAKE)[1]["records"]))
    def test_7_update_history_and_validation(self):
        rec = [r for r in call("GET", "/api/employer/dashboard", who=SUN)[1]["records"] if r["month"] == "2024-02"][0]
        d = {k: rec[k] for k in ("employee_name", "pf_member_id", "month", "pf_wages", "emp_epf", "ecr_status", "pay_status")}
        d.update(id=rec["id"], emp_epf=1500, ecr_status="Corrected")
        self.assertEqual(call("POST", "/api/employer/records", d, SUN)[0], 200)
        self.assertEqual(len(call("GET", f"/api/employer/history/{rec['id']}", who=SUN)[1]["history"]), 1)
        self.assertEqual(rows()[("Sun", "2024-02")]["reported"], 1500)
        self.assertEqual(call("POST", "/api/employer/records", dict(d, id=None, month="bad"), SUN)[0], 400)

# ---------------- Identity Verification + privacy ----------------
PAN = "ABCDE1234F"   # synthetic
def recs(who): return call("GET", "/api/identity/records", who=who)[1]["records"]
def lake(who): return [r for r in recs(who) if r["organization"].startswith("Lake")][0]
def fld(r, f): return [x for x in r["fields"] if x["field"] == f][0]
def notes(who): return call("GET", "/api/notifications", who=who)[1]["notifications"]
E = lambda **k: dict(dict(pf_member_id=app.PF_B, legal_name="Asha Demoo", dob="1995-06-16"), **k)

class Ident(unittest.TestCase):
    @classmethod
    def setUpClass(cls): app.init()
    def test_i1_compare_logic(self):
        e = dict(legal_name="Asha Demo", dob="1995-06-15", pan_idx=app.bidx(PAN))
        def r(**k): return dict(dict(legal_name="Asha Demo", dob="1995-06-15", pan_idx=app.bidx(PAN)), **k)
        res = lambda x, y=e: {c["field"]: c["result"] for c in app.compare(y, x)}
        self.assertEqual(set(res(r(legal_name="  ASHA   demo ")).values()), {"MATCH"})                 # case / spaces are safe
        self.assertEqual(res(r(legal_name="Asha Demoo"))["Legal name"], "PENDING REVIEW")              # spelling -> review
        self.assertEqual(res(r(legal_name="Ravi Kumar"))["Legal name"], "MISMATCH")
        self.assertEqual(res(r(dob="1995-06-16"))["Date of birth"], "MISMATCH")
        self.assertEqual(res(r(pan_idx=app.bidx("ZZZZZ9999Z")))["PAN"], "MISMATCH")
        self.assertEqual(res(r(pan_idx=None))["PAN"], "UNABLE TO COMPARE")                              # one side missing
        self.assertEqual(res(r(pan_idx=None), dict(e, pan_idx=None))["PAN"], "NOT PROVIDED")
        self.assertEqual(res(r(), None)["Legal name"], "UNABLE TO COMPARE")                             # employee has no identity yet
    def test_i2_seeded_demo_results(self):
        self.assertEqual({r["organization"][:3]: r["summary"] for r in recs(ASHA)}, {"Sun": "Matched", "Lak": "Discrepancy"})
        r = lake(ASHA)
        self.assertEqual([fld(r, f)["result"] for f in ("Legal name", "Date of birth", "PAN")], ["PENDING REVIEW", "MISMATCH", "UNABLE TO COMPARE"])
        self.assertEqual(fld(r, "Date of birth")["employer_value"], "1995-••-••")                       # other party's DOB is reduced
        self.assertEqual(fld(r, "Date of birth")["employee_value"], "1995-06-15")
        self.assertEqual(len(recs(LAKE)), 1); self.assertEqual(len(recs(SUN)), 1)
    def test_i3_no_identifier_leakage(self):
        blob = " ".join(str(call("GET", p, who=w)[1]) for w in (ASHA, SUN, LAKE) for p in ("/api/identity/records", "/api/notifications", "/api/employee/dashboard" if w == ASHA else "/api/employer/dashboard"))
        blob += str(call("GET", "/api/identity/me", who=ASHA)[1])
        self.assertNotIn(PAN, blob); self.assertNotIn(app.bidx(PAN), blob); self.assertIn("XXXXXX234F", blob)
        c = app.db(); raw = " ".join(str(tuple(r)) for t in ("identity_employee", "identity_employer", "audit_log", "notifications") for r in c.execute(f"select * from {t}")); c.close()
        self.assertNotIn(PAN, raw)                                                                       # encrypted at rest
        for n in notes(ASHA) + notes(LAKE): self.assertNotIn("1995", n["message"]); self.assertIn("Please sign in", n["message"])
    def test_i4_repeat_saves_do_not_duplicate_notifications(self):
        before = (len(notes(ASHA)), len(notes(LAKE))); self.assertEqual(before, (2, 2))
        for _ in range(3): self.assertEqual(call("POST", "/api/identity/employer-record", E(), LAKE)[0], 200)
        self.assertEqual((len(notes(ASHA)), len(notes(LAKE))), before); self.assertEqual(len(recs(LAKE)), 1)
        self.assertEqual(call("POST", "/api/identity/employer-record", E(dob="1995-07-01"), LAKE)[0], 200)   # a *changed* mismatch notifies again
        self.assertEqual(len(notes(ASHA)), 3)
        self.assertEqual(call("POST", "/api/identity/employer-record", E(), LAKE)[0], 200)                   # back to the original mismatch value
    def test_i5_review_notes_and_resolve(self):
        cid = fld(lake(ASHA), "Legal name")["case_id"]
        self.assertEqual(call("POST", f"/api/identity/cases/{cid}", dict(action="resolve", notes="ok"), ASHA)[0], 400)           # needs confirmation
        self.assertEqual(call("POST", f"/api/identity/cases/{cid}", dict(action="note", notes=f"pan is {PAN}"), ASHA)[0], 400)  # no ID numbers in notes
        self.assertEqual(call("POST", f"/api/identity/cases/{cid}", dict(action="review", notes="checking", evidence="ID card sighted"), ASHA)[0], 200)
        self.assertEqual(fld(lake(ASHA), "Legal name")["status"], "In review")
        self.assertEqual(call("POST", f"/api/identity/cases/{cid}", dict(action="resolve", confirm=True), ASHA)[0], 200)
        f = fld(lake(ASHA), "Legal name"); self.assertEqual((f["status"], f["resolved_by"]), ("Resolved", "Asha Demo (employee)"))
        c = app.db(); acts = [r[0] for r in c.execute("select action from audit_log where case_id=?", (cid,))]; c.close()
        self.assertIn("case_resolve", acts)
    def test_i6_correction_reruns_matching(self):
        self.assertEqual(fld(lake(LAKE), "Date of birth")["status"], "Open")
        self.assertEqual(call("POST", "/api/identity/employer-record", E(dob="1995-06-15"), LAKE)[0], 200)      # employer corrects only its own record
        f = fld(lake(ASHA), "Date of birth"); self.assertEqual((f["result"], f["status"]), ("MATCH", "Resolved")); self.assertIn("System", f["resolved_by"])
        self.assertEqual(fld(lake(ASHA), "Legal name")["status"], "Resolved")        # untouched: stays resolved, not silently changed
        self.assertEqual(call("GET", "/api/identity/me", who=ASHA)[1]["profile"]["dob"], "1995-06-15")
    def test_i7_isolation_and_permissions(self):
        cid = fld(lake(ASHA), "Date of birth")["case_id"]
        self.assertEqual(call("POST", f"/api/identity/cases/{cid}", dict(action="note", notes="x"), SUN)[0], 404)    # other employer
        self.assertEqual(call("POST", "/api/register", dict(role="employee", email="bob@demo.test", password="demo1234", name="Bob Demo"))[0], 200)
        self.assertEqual(recs("bob@demo.test"), [])                                                                  # other employee sees nothing
        self.assertEqual(call("POST", f"/api/identity/cases/{cid}", dict(action="note", notes="x"), "bob@demo.test")[0], 404)
        self.assertEqual(call("POST", "/api/identity/delete", dict(id=1), LAKE)[0] in (200, 404), True)
        sun_rec = recs(SUN)[0]["id"]; self.assertEqual(call("POST", "/api/identity/delete", dict(id=sun_rec), LAKE)[0], 404)  # cannot delete another org's record
        self.assertEqual(len(recs(SUN)), 1)
    def test_i8_unauthenticated_and_wrong_role(self):
        for m, p in (("GET", "/api/identity/records"), ("GET", "/api/notifications"), ("POST", "/api/identity/me"), ("POST", "/api/identity/cases/1")):
            self.assertEqual(call(m, p)[0], 401)
        self.assertEqual(call("POST", "/api/identity/me", dict(legal_name="X", dob="1990-01-01"), LAKE)[0], 403)
        self.assertEqual(call("POST", "/api/identity/employer-record", E(), ASHA)[0], 403)
    def test_i9_validation_and_erasure(self):
        code, body = call("POST", "/api/identity/me", dict(legal_name="Asha Demo", dob="1995-06-15", pan="BADPAN123"), ASHA)
        self.assertEqual(code, 400); self.assertNotIn("BADPAN123", str(body))
        self.assertEqual(call("POST", "/api/identity/me", dict(legal_name="Asha Demo", dob="2099-01-01"), ASHA)[0], 400)
        self.assertEqual(call("POST", "/api/identity/delete", {}, ASHA)[0], 200)
        self.assertIsNone(call("GET", "/api/identity/me", who=ASHA)[1]["profile"])
        self.assertEqual(lake(ASHA)["summary"], "Unable to compare")

# ---------------- Issue Resolution & Contact Assistant ----------------
BOB = "bob@demo.test"
def G(cat, who=ASHA, **k): return call("POST", "/api/assistant/guidance", dict(category=cat, **k), who)
def mk(cat="contribution_mismatch", who=ASHA, **k): return call("POST", "/api/issues", dict(category=cat, **k), who)
CATKEYS = ["contribution_mismatch", "ecr_not_submitted", "challan_not_generated", "payment_not_reflected", "identity_mismatch", "claim_transfer_delay", "employment_overlap", "other"]

class TIssues(unittest.TestCase):
    @classmethod
    def setUpClass(cls): app.init()
    def test_a1_context_and_all_categories(self):
        code, ctx = call("GET", "/api/assistant/context", who=ASHA); self.assertEqual(code, 200)
        self.assertEqual([c["key"] for c in ctx["categories"]], CATKEYS); self.assertEqual(ctx["grievance_url"], "https://epfigms.gov.in/")
        self.assertTrue(all("DEMO" in c["label"] and c["phone"] == "Demo contact — no real phone number" and c["email"].endswith("@example.com") for c in ctx["contacts"]))
        titles = set()
        for k in CATKEYS:
            code, g = G(k); self.assertEqual(code, 200, k)
            self.assertGreaterEqual(len(g["steps"]), 4); self.assertTrue(g["documents"]); self.assertIn("DEMO", g["contact"]["label"]); self.assertIn("not " + app.DEMO_ORG, g["contact_notice"])
            self.assertIn("Dear", g["message"]["body"]); titles.add(g["explanation"])
        self.assertEqual(len(titles), 8)
        self.assertEqual(G("contribution_mismatch")[1]["contact"]["title"], "Payroll & PF Officer"); self.assertEqual(G("employment_overlap")[1]["contact"]["title"], "HR Manager")
        self.assertEqual(G("other")[1]["contact"]["title"], "Grievance Coordinator"); self.assertEqual(G("nope")[0], 400)
    def test_a2_template_uses_only_own_data_or_placeholders(self):
        rec = [r for r in call("GET", "/api/assistant/context", who=ASHA)[1]["records"] if r["employer_name"].startswith("Sun") and r["month"] == "2024-02"][0]
        g = G("payment_not_reflected", reconciliation_id=rec["id"])[1]; b = g["message"]["body"]
        self.assertIn("2024-02", b); self.assertIn("ending 0001", b); self.assertNotIn(app.PF_A, b); self.assertIn("[Passbook Amount, if available]", b)
        g = G("challan_not_generated")[1]["message"]["body"]; self.assertIn("[Wage Month]", g); self.assertIn("[Reference Number]", g)
        g = G("contribution_mismatch", reconciliation_id=rec["id"])[1]; self.assertIn("estimate only", g["message"]["body"]); self.assertIn("not assuming an error", g["message"]["body"])
        self.assertIn("No employer ECR record", " ".join(G("ecr_not_submitted", reconciliation_id=[r for r in call("GET", "/api/assistant/context", who=ASHA)[1]["records"] if r["classification"] == "Missing record"][0]["id"])[1]["facts"]) if any(r["classification"] == "Missing record" for r in call("GET", "/api/assistant/context", who=ASHA)[1]["records"]) else "No employer ECR record")
        self.assertEqual(G("contribution_mismatch", reconciliation_id=999999)[0], 404)
        self.assertEqual(G("contribution_mismatch", who=BOB, reconciliation_id=rec["id"])[0], 404)     # another employee's record id
    def test_a3_overlap_facts_and_identity_no_values(self):
        f = " ".join(G("employment_overlap")[1]["facts"]); self.assertIn("Sunrise", f); self.assertIn("Lakeview", f); self.assertIn("Overlapping months", f)
        blob = str(G("identity_mismatch")[1]); self.assertNotIn(PAN, blob); self.assertNotIn("1995", blob)
    def test_a4_track_persist_duplicate_notify(self):
        code, r = mk("payment_not_reflected", description="Payment shown but no passbook line", follow_up_date="2099-01-01"); self.assertEqual((code, r["duplicate"]), (200, False)); iid = r["issue"]["id"]
        self.assertEqual(r["issue"]["status"], "Open"); self.assertIn("(demo)", r["issue"]["contact"])
        n0 = len([n for n in notes(ASHA) if "Issue saved" in n["message"]])
        for _ in range(3): code, d = mk("payment_not_reflected"); self.assertEqual((code, d["duplicate"], d["issue"]["id"]), (200, True, iid))
        self.assertEqual(len(call("GET", "/api/issues", who=ASHA)[1]["issues"]), 1)
        self.assertEqual(len([n for n in notes(ASHA) if "Issue saved" in n["message"]]), n0)
        self.assertEqual(n0, 1); self.assertIn("no email was sent", [n for n in notes(ASHA) if "Issue saved" in n["message"]][0]["message"])
        code, d = mk("payment_not_reflected", create_another=True); self.assertFalse(d["duplicate"]); self.assertNotEqual(d["issue"]["id"], iid)
        app.init(); self.assertEqual(len(call("GET", "/api/issues", who=ASHA)[1]["issues"]), 2)        # survives re-init (restart)
    def test_a5_status_notes_resolve_and_audit(self):
        iid = call("GET", "/api/issues", who=ASHA)[1]["issues"][-1]["id"]; p = f"/api/issues/{iid}"
        self.assertEqual(call("POST", p + "/status", dict(status="Bogus"), ASHA)[0], 400)
        self.assertEqual(call("POST", p + "/status", dict(status="Waiting for Employer"), ASHA)[0], 200)
        k = len([n for n in notes(ASHA) if "changed to Waiting for Employer" in n["message"]]); self.assertEqual(k, 1)
        self.assertTrue(call("POST", p + "/status", dict(status="Waiting for Employer"), ASHA)[1]["unchanged"])                        # same status: no event, no notification
        self.assertEqual(len([n for n in notes(ASHA) if "changed to Waiting for Employer" in n["message"]]), 1)
        self.assertEqual(call("POST", p + "/note", dict(note="Emailed payroll on 5 Jan"), ASHA)[0], 200)
        self.assertEqual(call("POST", p + "/note", dict(note=f"my pan {PAN}"), ASHA)[0], 400); self.assertEqual(call("POST", p + "/note", dict(note="uan 123456789012"), ASHA)[0], 400)
        self.assertEqual(call("POST", p + "/status", dict(status="Resolved"), ASHA)[0], 400)                                         # needs confirmation
        self.assertEqual(call("POST", p + "/status", dict(status="Resolved", confirm=True), ASHA)[0], 200)
        d = call("GET", p, who=ASHA)[1]["issue"]; self.assertEqual(d["status"], "Resolved"); self.assertEqual(len(d["notes"]), 1)
        self.assertEqual([e["event"] for e in d["events"]], ["status_changed", "note_added", "status_changed", "created"])
        c = app.db(); self.assertTrue(c.execute("select 1 from audit_log where action='issue_status_changed'").fetchone()); c.close()
        self.assertEqual(call("POST", "/api/issues", dict(category="payment_not_reflected", description="again"), ASHA)[1]["duplicate"], True)   # other active one still exists
    def test_a6_validation_other_and_plan(self):
        self.assertEqual(mk("other")[0], 400); self.assertEqual(mk("other", description="x" * 1001)[0], 400); self.assertEqual(mk("other", description=f"PAN {PAN}")[0], 400)
        self.assertEqual(mk("other", description="ok", follow_up_date="31-12-2030")[0], 400); self.assertEqual(mk("claim_transfer_delay", reference="ABCDE1234F")[0], 400)
        code, r = mk("other", description="Employer name changed after merger"); self.assertEqual(code, 200)
        self.assertEqual(mk("other", description="employer NAME changed after merger")[1]["duplicate"], True)
        iid = r["issue"]["id"]; self.assertEqual(call("POST", f"/api/issues/{iid}/plan", dict(next_action="Call HR", follow_up_date="2099-02-01"), ASHA)[0], 200)
        self.assertEqual(call("GET", f"/api/issues/{iid}", who=ASHA)[1]["issue"]["follow_up_date"], "2099-02-01")
    def test_a7_followup_notification_once(self):
        code, r = mk("employment_overlap", follow_up_date="2020-01-01"); self.assertEqual(code, 200)
        for _ in range(3): call("GET", "/api/issues", who=ASHA)
        self.assertEqual(len([n for n in notes(ASHA) if "Follow-up due" in n["message"]]), 1)
        self.assertTrue([i for i in call("GET", "/api/issues", who=ASHA)[1]["issues"] if i["id"] == r["issue"]["id"]][0]["due"])
    def test_a8_authorization(self):
        iid = call("GET", "/api/issues", who=ASHA)[1]["issues"][0]["id"]
        if call("POST", "/api/register", dict(role="employee", email=BOB, password="demo1234", name="Bob Demo"))[0] not in (200, 409): self.fail("register")
        for m, p, b in (("GET", f"/api/issues/{iid}", None), ("POST", f"/api/issues/{iid}/status", dict(status="Closed")), ("POST", f"/api/issues/{iid}/note", dict(note="hi"))):
            self.assertEqual(call(m, p, b, BOB)[0], 404)
        self.assertEqual(call("GET", "/api/issues", who=BOB)[1]["issues"], [])
        for w in (SUN, LAKE): self.assertEqual(call("GET", "/api/issues", who=w)[0], 403); self.assertEqual(call("POST", "/api/assistant/guidance", dict(category="other"), w)[0], 403)
        for m, p in (("GET", "/api/issues"), ("GET", "/api/assistant/context"), ("POST", "/api/issues"), ("GET", "/api/issues/1"), ("POST", "/api/assistant/guidance")): self.assertEqual(call(m, p)[0], 401)
        self.assertEqual(call("GET", f"/api/issues/{iid}", who=ASHA)[0], 200)
    def test_a9_no_sensitive_leak_and_idempotent_seed(self):
        blob = " ".join(str(call("GET", p, who=ASHA)[1]) for p in ("/api/assistant/context", "/api/issues", "/api/notifications")) + str(G("identity_mismatch")[1]) + str(G("contribution_mismatch")[1])
        self.assertNotIn(PAN, blob); self.assertNotIn(app.PF_A, blob); self.assertNotIn(app.PF_B, blob); self.assertNotIn(app.bidx(PAN), blob)
        c = app.db(); app.init(); app.seed_contacts(c); c.commit(); self.assertEqual(c.execute("select count(*) from demo_contacts").fetchone()[0], 3)
        raw = " ".join(str(tuple(r)) for t in ("issues", "issue_notes", "issue_events") for r in c.execute(f"select * from {t}")); c.close(); self.assertNotIn(PAN, raw)
    def test_b1_grievance_url_is_configurable_and_https_only(self):
        os.environ["PROVIDENT360_GRIEVANCE_URL"] = "javascript:alert(1)"
        try: self.assertEqual(app.grievance_url(), "https://epfigms.gov.in/")
        finally: del os.environ["PROVIDENT360_GRIEVANCE_URL"]
if __name__ == "__main__": unittest.main()