"""Tests for the Sensitive Screenshot & OTP Protection feature. Real HTTP server, real tesseract OCR, SYNTHETIC images only.
Run:  python Test_upload_guard.py
"""
import contextlib, http.client, inspect, io, json, os, re, sqlite3, stat, sys, tempfile, threading, unittest
from unittest import mock

_TMP = tempfile.mkdtemp(); tempfile.tempdir = os.path.join(_TMP, "systmp"); os.makedirs(tempfile.tempdir)
os.environ.update(PROVIDENT360_DB=os.path.join(_TMP, "t.db"), PROVIDENT360_UPLOADS=os.path.join(_TMP, "uploads_private"),
                  P360_UPLOADS_PER_MINUTE="1000", TMPDIR=tempfile.tempdir)
from cryptography.fernet import Fernet
os.environ["PROVIDENT360_KEY"] = Fernet.generate_key().decode()
for k in [k for k in os.environ if k.startswith("P360_FAIL_CLOSED") or k in ("P360_SCAN_ALLOW",)]: del os.environ[k]
from http.server import ThreadingHTTPServer
from PIL import Image
import app, image_scan, sensitive_detect as sd
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "tests"))
import make_synthetic_images as synth

OTP = "482731"
SYN = synth.OUT
def img(name):
    with open(os.path.join(SYN, name), "rb") as f: return f.read()
def png_bytes(im, fmt="PNG", **kw):
    b = io.BytesIO(); im.save(b, fmt, **kw); return b.getvalue()
ASHA, SUN = "asha@demo.test", "hr@sunrise.demo.test"
UPLOADS = lambda: app.uploads_dir()
def upload_files(): return sorted(p.name for p in UPLOADS().iterdir())

class Client:
    def __init__(self, port, who=None):
        self.port, self.cookie = port, ""
        if who:
            st, _, h = self.req("POST", "/api/login", json.dumps({"email": who, "password": "demo1234"}).encode(), {"Content-Type": "application/json"})
            self.cookie = h["Set-Cookie"].split(";")[0]
    def req(self, method, path, body=None, headers=None, raw_len=None):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=60)
        hd = dict(headers or {});
        if self.cookie: hd["Cookie"] = self.cookie
        if raw_len is not None:
            c.putrequest(method, path); [c.putheader(k, v) for k, v in hd.items()]; c.putheader("Content-Length", str(raw_len)); c.endheaders(body or b"")
        else: c.request(method, path, body=body, headers=hd)
        r = c.getresponse(); data = r.read(); out = (r.status, data, dict(r.getheaders())); c.close(); return out
    def upload(self, path, data, ctype="application/octet-stream", extra=None, csrf=True):
        h = {"Content-Type": ctype};
        if csrf: h["X-P360-Upload"] = "1"
        h.update(extra or {})
        st, body, hdr = self.req("POST", path, data, h)
        try: return st, json.loads(body)
        except ValueError: return st, {"_raw": body}
    def doc(self, data, **kw): return self.upload("/api/documents/upload?purpose=claim_support", data, **kw)

class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        synth.make(); app.init()
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), app.H); cls.port = cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.asha, cls.sun, cls.anon = Client(cls.port, ASHA), Client(cls.port, SUN), Client(cls.port)
    @classmethod
    def tearDownClass(cls): cls.srv.shutdown(); cls.srv.server_close()
    def rows(self, q, a=()):
        c = sqlite3.connect(os.environ["PROVIDENT360_DB"]); c.row_factory = sqlite3.Row
        try: return c.execute(q, a).fetchall()
        finally: c.close()
    def nothing_stored(self):
        self.assertEqual(upload_files(), [], "files exist in the private upload dir"); self.assertEqual(self.rows("select * from uploads"), [])
        self.assertEqual(os.listdir(tempfile.tempdir), [], "temporary files left behind")
    def clear(self):
        for r in self.rows("select * from uploads"): self.asha.req("POST", f"/api/uploads/{r['id']}/delete", b"{}", {"Content-Type": "application/json"})
    def issue_id(self):
        r = self.rows("select id from issues where user_id=(select id from users where email=?) limit 1", (ASHA,))
        if r: return r[0]["id"]
        st, b, _ = self.asha.req("POST", "/api/issues", json.dumps({"category": "other", "description": "Demo issue for attachments"}).encode(), {"Content-Type": "application/json"})
        return json.loads(b)["issue"]["id"]

class T1_Detection(unittest.TestCase):
    def cats(self, t): return {f.category for f in sd.analyse(t, allow=())}
    def test_otp_wording_and_formats(self):
        for t in ["Your OTP is 482731", "482731 is your verification code", "verification code 482731", "Use 482-731 as your login code", "OTP: 4827",
                  "Your one-time password: 48273190", "Your 0TP is 482731", "G-482731 is your Google verification code"]:
            self.assertIn("otp", self.cats(t), t)
    def test_bare_numbers_are_not_blocked(self):
        for t in ["Order 482731 shipped", "Invoice 2024-03 total Rs. 1,482.00", "Receipt #482731 dated 24/10/2026", "Phone 98765 43210"]:
            self.assertEqual(self.cats(t), set(), t)
    def test_wording_without_code_is_uncertain(self):
        self.assertEqual(self.cats("Enter the verification code sent to your phone. It expires in 10 minutes."), {"uncertain_otp"})
    def test_identifiers(self):
        self.assertIn("aadhaar", self.cats("Aadhaar 2345 6789 0123")); self.assertIn("pan", self.cats("PAN ABCPD1234E"))
        self.assertIn("uan", self.cats("UAN: 100123456789")); self.assertIn("bank_account", self.cats("A/c No 123456789012"))
        self.assertIn("card", self.cats("4111 1111 1111 1111")); self.assertIn("credential", self.cats("your UPI PIN is 4821"))
    def test_allow_list_never_covers_otp(self):
        self.assertEqual({f.category for f in sd.analyse("PAN ABCPD1234E", allow=("pan",))}, set())
        self.assertIn("otp", {f.category for f in sd.analyse("Your OTP is 482731", allow=("otp", "pan"))})
    def test_findings_carry_no_values(self):
        for f in sd.analyse("Your OTP is 482731"): self.assertNotIn(OTP, repr(f)); self.assertEqual(set(f.__dataclass_fields__), {"category", "certain"})

class T2_Blocking(Base):
    def setUp(self): self.clear()
    def test_a_otp_sms_blocked(self):
        st, j = self.asha.doc(img("otp_sms.png")); self.assertEqual(st, 422); self.assertTrue(j["blocked"]); self.assertEqual(j["code"], "OTP_DETECTED")
        self.assertEqual(j["title"], "Sensitive information detected"); self.assertIn("one-time password (OTP) or verification code", j["message"])
        self.assertIn("Never share an OTP with anyone, including support staff.", j["message"]); self.assertEqual([a["id"] for a in j["actions"]], ["redact", "choose", "cancel"])
    def test_b_verification_code_blocked(self):
        st, j = self.asha.doc(img("verification_code.png")); self.assertEqual((st, j["code"]), (422, "OTP_DETECTED"))
    def test_other_otp_layouts_blocked(self):
        for n in ("otp_code_first.png", "otp_dark_mode.png", "otp_rotated.png", "otp_spaced.png"):
            st, j = self.asha.doc(img(n)); self.assertEqual((st, j.get("code")), (422, "OTP_DETECTED"), n)
    def test_c_otp_never_in_response(self):
        for n in ("otp_sms.png", "verification_code.png", "otp_dark_mode.png", "ambiguous_verification.png"):
            st, body, hdr = self.asha.req("POST", "/api/documents/upload?purpose=other", img(n), {"X-P360-Upload": "1"})
            text = body.decode().lower()
            for bad in (OTP, "482 731", "482-731", "valid for", "do not share it", "sent to your phone", "expire"): self.assertNotIn(bad, text + json.dumps(dict(hdr)).lower(), n)
    def test_d_e_rejected_image_not_retained_anywhere(self):
        for n in ("otp_sms.png", "verification_code.png", "aadhaar_synthetic.png", "ambiguous_verification.png"): self.asha.doc(img(n))
        self.nothing_stored()
        blob = b"".join(open(os.path.join(dp, f), "rb").read() for dp, _, fs in os.walk(_TMP) for f in fs if f not in ("t.db",))   # everything on disk outside the DB
        for n in ("otp_sms.png", "verification_code.png"): self.assertNotIn(img(n)[:64] + img(n)[-64:], blob)
        dump = "\n".join(sqlite3.connect(os.environ["PROVIDENT360_DB"]).iterdump()).lower()
        for bad in (OTP, "do not share", "valid for 10", "verification code"): self.assertNotIn(bad, dump)
    def test_identifier_screenshots_blocked(self):
        for n, cat in (("aadhaar_synthetic.png", "aadhaar"), ("pan_synthetic.png", "pan")):
            st, j = self.asha.doc(img(n)); self.assertEqual((st, j["code"], j["categories"]), (422, "SENSITIVE_DETECTED", [cat]))
            self.assertNotIn("2345", json.dumps(j)); self.assertNotIn("ABCPD", json.dumps(j))
    def test_f_normal_receipt_uploads_and_is_private(self):
        st, j = self.asha.doc(img("receipt_clean.png")); self.assertEqual(st, 200, j); self.assertTrue(j["verified"]); uid = j["upload"]["id"]
        files = upload_files(); self.assertEqual(len(files), 1)
        p = UPLOADS() / files[0]; self.assertEqual(stat.S_IMODE(p.stat().st_mode), 0o600); self.assertEqual(stat.S_IMODE(UPLOADS().stat().st_mode), 0o700)
        self.assertFalse(p.read_bytes().startswith(b"\x89PNG"), "stored file must be encrypted at rest")
        st, body, hdr = self.asha.req("GET", f"/api/uploads/{uid}/file"); self.assertEqual((st, hdr["Content-Type"]), (200, "image/png")); Image.open(io.BytesIO(body)).verify()
        self.assertEqual(self.sun.req("GET", f"/api/uploads/{uid}/file")[0], 404); self.assertEqual(self.anon.req("GET", f"/api/uploads/{uid}/file")[0], 401)
        self.assertEqual(self.asha.req("GET", "/api/uploads/../../app.py")[0], 404)     # traversal is just an unknown API path; no file is ever read by name
        self.assertEqual(os.listdir(tempfile.tempdir), [])
    def test_f2_metadata_stripped(self):
        im = Image.open(os.path.join(SYN, "receipt_clean.png")).convert("RGB"); ex = Image.Exif(); ex[0x010E] = "SYNTHETIC-GPS-AND-OWNER-NAME"; ex[0x0112] = 1
        jpg = png_bytes(im, "JPEG", exif=ex.tobytes()); self.assertIn(b"SYNTHETIC-GPS", jpg)
        st, j = self.asha.doc(jpg); self.assertEqual(st, 200, j)
        _, body, _ = self.asha.req("GET", f"/api/uploads/{j['upload']['id']}/file"); self.assertNotIn(b"SYNTHETIC-GPS", body); self.assertEqual(len(Image.open(io.BytesIO(body)).getexif()), 0)
    def test_f3_image_without_text_is_accepted(self):
        for n in ("blank.png", "no_otp_text.png"): self.assertEqual(self.asha.doc(img(n))[0], 200, n)
    def test_g_ambiguous_triggers_safe_warning_and_is_configurable(self):
        st, j = self.asha.doc(img("ambiguous_verification.png")); self.assertEqual((st, j["code"]), (422, "POSSIBLE_OTP_UNVERIFIED"))
        self.assertEqual(j["title"], "This image could not be verified as safe"); self.assertIn("permanently redacted", j["message"]); self.nothing_stored()
        with mock.patch.dict(os.environ, {"P360_FAIL_CLOSED_DOCUMENTS": "0"}):
            st, j = self.asha.doc(img("ambiguous_verification.png")); self.assertEqual(st, 200); self.assertFalse(j["verified"])
        with mock.patch.dict(os.environ, {"P360_FAIL_CLOSED_DOCUMENTS": "0"}):               # but a real OTP is never allowed, even fail-open
            self.assertEqual(self.asha.doc(img("otp_sms.png"))[0], 422)
    def test_redacted_image_can_be_uploaded_after_block(self):
        im = Image.open(os.path.join(SYN, "otp_sms.png")).convert("RGB"); self.assertEqual(self.asha.doc(png_bytes(im))[0], 422)
        from PIL import ImageDraw
        ImageDraw.Draw(im).rectangle([0, 0, 720, 360], fill=(0, 0, 0))                         # permanent redaction (pixels replaced)
        st, j = self.asha.doc(png_bytes(im)); self.assertEqual(st, 200, j)

class T3_Failure(Base):
    def setUp(self): self.clear()
    def test_h_ocr_unavailable_fails_closed(self):
        with mock.patch.object(image_scan, "tesseract_path", return_value="/nonexistent/tesseract"):
            st, j = self.asha.doc(img("receipt_clean.png")); self.assertEqual((st, j["code"], j["retry"]), (503, "SCANNER_UNAVAILABLE", True))
            self.assertIn("not saved", j["message"]); self.nothing_stored()
            with mock.patch.dict(os.environ, {"P360_FAIL_CLOSED": "0"}):                           # operator-approved fail-open
                st, j = self.asha.doc(img("receipt_clean.png")); self.assertEqual(st, 200); self.assertFalse(j["verified"])
    def test_h_ocr_timeout_fails_closed(self):
        slow = os.path.join(_TMP, "slow_tesseract")
        with open(slow, "w") as f: f.write("#!/bin/sh\nsleep 20\n")
        os.chmod(slow, 0o755)
        with mock.patch.dict(os.environ, {"P360_TESSERACT": slow, "P360_OCR_TIMEOUT": "2"}):
            st, j = self.asha.doc(img("receipt_clean.png")); self.assertEqual((st, j["code"]), (503, "SCAN_TIMEOUT")); self.nothing_stored()
    def test_h_ocr_crash_message_not_leaked(self):
        with mock.patch.object(image_scan, "_ocr", side_effect=RuntimeError(f"boom OTP {OTP}")):
            st, body, _ = self.asha.req("POST", "/api/documents/upload?purpose=other", img("receipt_clean.png"), {"X-P360-Upload": "1"})
        self.assertEqual(st, 503); self.assertNotIn(OTP.encode(), body); self.nothing_stored()
    def test_scanner_missing_module_fails_closed(self):
        with mock.patch.object(app, "image_scan", None):
            st, j = self.asha.doc(img("receipt_clean.png")); self.assertEqual(st, 503); self.nothing_stored()
    def test_i_invalid_files_rejected(self):
        ok = img("receipt_clean.png")
        cases = {"text-as-png": (b"Your OTP is 482731 but this is text", 415), "gif": (png_bytes(Image.new("RGB", (60, 60)), "GIF"), 415), "pdf": (b"%PDF-1.4\n%fake", 415),
                 "svg": (b"<svg xmlns='http://www.w3.org/2000/svg'><text>OTP 482731</text></svg>", 415), "truncated": (ok[:len(ok) // 2], 400), "empty": (b"", 400),
                 "corrupt-body": (ok[:40] + b"\x00" * 500, 400), "tiny": (png_bytes(Image.new("RGB", (4, 4))), 400),
                 "mismatch": (png_bytes(Image.new("RGB", (60, 60)), "JPEG").replace(b"\xff\xd8\xff", b"\x89PNG\r\n\x1a\n", 1), 400)}
        for name, (data, want) in cases.items():
            for ctype in ("image/png", "application/pdf"):                                      # client-declared MIME is irrelevant
                st, j = self.asha.doc(data, ctype=ctype); self.assertIn(st, (want, 415, 400, 411), name); self.assertGreaterEqual(st, 400, name)
        self.nothing_stored()
    def test_i_oversized_rejected(self):
        with mock.patch.dict(os.environ, {"P360_MAX_IMAGE_BYTES": "20000"}):
            noise = os.urandom(24000); st, j = self.asha.doc(b"\x89PNG\r\n\x1a\n" + noise); self.assertEqual((st, j["code"]), (413, "TOO_LARGE"))
        st, body, _ = self.asha.req("POST", "/api/documents/upload", b"", {"X-P360-Upload": "1"}, raw_len=60_000_000); self.assertEqual(st, 413)   # refused without reading the body
        bomb = png_bytes(Image.new("1", (12000, 12000))); self.assertLess(len(bomb), 1_000_000)
        st, j = self.asha.doc(bomb); self.assertIn(st, (400, 413)); self.nothing_stored()
        self.assertEqual(self.asha.req("POST", "/api/documents/upload", b"x", {"X-P360-Upload": "1", "Transfer-Encoding": "chunked"})[0], 411)
    def test_animated_rejected(self):
        a, b = Image.new("RGB", (80, 80), "white"), Image.new("RGB", (80, 80), "black")
        st, j = self.asha.doc(png_bytes(a, "WEBP", save_all=True, append_images=[b], duration=100)); self.assertIn(st, (415, 400)); self.nothing_stored()

class T4_Enforcement(Base):
    def setUp(self): self.clear()
    def routes(self):
        iid = self.issue_id()
        return {"documents": "/api/documents/upload?purpose=other", "kyc": "/api/identity/kyc/upload", "issue_attachment": f"/api/issues/{iid}/attachments"}
    def test_j_same_protection_regardless_of_how_client_sent_it(self):
        for ctype, extra in (("image/png", {}), ("application/octet-stream", {}), ("image/jpeg", {}), ("text/plain", {}), ("image/png", {"Origin": f"http://127.0.0.1:{self.port}"})):
            st, j = self.asha.doc(img("otp_sms.png"), ctype=ctype, extra=extra); self.assertEqual((st, j["code"]), (422, "OTP_DETECTED"), ctype)
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "static", "index.html"), encoding="utf-8") as f: html = f.read()
        for handler in ("drop", "paste", "change"):                                              # all three client entry points go through the single UP.submit
            m = re.search(r"addEventListener\(\"%s\",[\s\S]{0,400}?UP\.submit\(" % handler, html); self.assertTrue(m, handler)
    def test_k_every_route_enforces_scanning(self):
        self.assertEqual(set(self.routes()), set(app.UPLOAD_ROUTES), "a route was added without a test")
        for name, path in self.routes().items():
            st, j = self.asha.upload(path, img("otp_sms.png")); self.assertEqual((st, j.get("code")), (422, "OTP_DETECTED"), name)
            st, j = self.asha.upload(path, b"not an image"); self.assertEqual(st, 415, name)
            with mock.patch.object(image_scan, "scan_upload", wraps=image_scan.scan_upload) as spy:      # client-side checks are irrelevant: server always scans
                self.asha.upload(path, img("receipt_clean.png")); self.assertEqual(spy.call_count, 1, name)
        src = inspect.getsource(app); self.assertEqual(src.count("rfile.read("), 2, "a new body reader appeared outside the guarded path")
        code = "\n".join(l.split("#")[0] for l in src.splitlines()); self.assertEqual(code.count("image_scan.scan_upload("), 1); self.assertEqual(code.count("store_upload("), 2)   # definition + the single guarded call
    def test_k_scan_result_is_honoured_even_if_scanner_stubbed(self):
        stub = image_scan.ScanResult("blocked", "OTP_DETECTED", ("otp",), http=422)
        with mock.patch.object(image_scan, "scan_upload", return_value=stub):
            for name, path in self.routes().items(): self.assertEqual(self.asha.upload(path, img("receipt_clean.png"))[0], 422, name)
        self.nothing_stored()
    def test_l_temp_files_cleaned_on_exception(self):
        with mock.patch("os.replace", side_effect=OSError("disk full")):
            st, body, _ = self.asha.req("POST", "/api/documents/upload?purpose=other", img("receipt_clean.png"), {"X-P360-Upload": "1"})
        self.assertEqual(st, 500); self.assertNotIn(b"disk full", body); self.nothing_stored()
        with mock.patch.object(app, "audit", side_effect=RuntimeError("db down")):
            self.assertEqual(self.asha.doc(img("receipt_clean.png"))[0], 500)
        self.nothing_stored()
    def test_m_logs_db_notifications_errors_contain_no_otp(self):
        err, out = io.StringIO(), io.StringIO()
        with contextlib.redirect_stderr(err), contextlib.redirect_stdout(out):
            for n in ("otp_sms.png", "verification_code.png", "ambiguous_verification.png"): self.asha.doc(img(n))
            with mock.patch.object(image_scan, "_ocr", side_effect=RuntimeError(f"OTP {OTP}")): self.asha.doc(img("receipt_clean.png"))
        self.assertNotIn(OTP, err.getvalue() + out.getvalue())
        audit = " ".join(" ".join(map(str, r)) for r in self.rows("select actor,action,case_id,detail,at from audit_log where action like 'upload_%'")); self.assertIn("upload_blocked", audit)
        self.assertIn("reason=OTP_DETECTED", audit); self.assertNotIn(OTP, audit); self.assertNotIn("sms", audit.lower())
        for t in ("notifications", "issue_notes", "issue_events", "issues"):
            self.assertNotIn(OTP, json.dumps([tuple(r) for r in self.rows(f"select * from {t}")]), t)
        self.assertEqual(self.rows("select count(*) c from uploads")[0]["c"], 0)
    def test_n_authentication_and_authorisation(self):
        with mock.patch.object(image_scan, "scan_upload", side_effect=AssertionError("scanned an unauthenticated body")):
            for path in self.routes().values(): self.assertEqual(self.anon.upload(path, img("receipt_clean.png"))[0], 401, path)
        iid = self.issue_id()
        self.assertEqual(self.sun.upload(f"/api/issues/{iid}/attachments", img("receipt_clean.png"))[0], 403)             # employer cannot use employee issue route
        self.assertEqual(self.asha.upload("/api/issues/999999/attachments", img("receipt_clean.png"))[0], 404)
        self.assertEqual(self.asha.upload("/api/documents/upload?purpose=../etc", img("receipt_clean.png"))[0], 400)
        self.assertEqual(self.asha.upload("/api/documents/upload", img("receipt_clean.png"), csrf=False)[0], 403)         # CSRF header required
        self.assertEqual(self.asha.upload("/api/documents/upload", img("receipt_clean.png"), extra={"Origin": "https://evil.example"})[0], 403)
        self.assertEqual(self.asha.req("GET", "/api/employee/dashboard")[0], 200); self.assertEqual(self.anon.req("GET", "/api/employee/dashboard")[0], 401)
        st, j = self.asha.doc(img("receipt_clean.png")); self.assertEqual(st, 200); uid = j["upload"]["id"]
        self.assertEqual(self.sun.req("POST", f"/api/uploads/{uid}/delete", b"{}", {"Content-Type": "application/json"})[0], 404)          # other user cannot delete
        self.assertEqual(json.loads(self.sun.req("GET", "/api/uploads")[1])["uploads"], [])
        self.assertEqual(self.asha.req("POST", f"/api/uploads/{uid}/delete", b"{}", {"Content-Type": "application/json"})[0], 200); self.assertEqual(upload_files(), [])
    def test_n_rate_limit(self):
        with mock.patch.dict(os.environ, {"P360_UPLOADS_PER_MINUTE": "3"}):
            app._RATE.clear(); codes = [self.asha.doc(img("receipt_clean.png"))[0] for _ in range(5)]
        self.assertEqual(codes[:3], [200] * 3); self.assertEqual(codes[3:], [429, 429]); app._RATE.clear()
    def test_issue_attachment_flow(self):
        iid = self.issue_id(); st, j = self.asha.upload(f"/api/issues/{iid}/attachments", img("receipt_clean.png")); self.assertEqual(st, 200)
        up = json.loads(self.asha.req("GET", "/api/uploads")[1])["uploads"]; self.assertEqual([(u["route"], u["issue_id"]) for u in up], [("issue_attachment", iid)])
    def test_kyc_blocks_pan_by_default_and_allow_list_works(self):
        self.assertEqual(self.asha.upload("/api/identity/kyc/upload", img("pan_synthetic.png"))[0], 422)
        with mock.patch.dict(os.environ, {"P360_SCAN_ALLOW": "pan"}): self.assertEqual(self.asha.upload("/api/identity/kyc/upload", img("pan_synthetic.png"))[0], 200)
        with mock.patch.dict(os.environ, {"P360_SCAN_ALLOW": "pan,otp"}): self.assertEqual(self.asha.upload("/api/identity/kyc/upload", img("otp_sms.png"))[0], 422)

if __name__ == "__main__":
    unittest.main(verbosity=2)