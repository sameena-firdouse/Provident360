# Sensitive Screenshot & OTP Protection

Every image a user uploads to Provident360 is scanned **on the server, in memory, before anything is written to disk**.
If the image appears to show an OTP / verification code (or Aadhaar, PAN, UAN, bank-account, card, PIN/password details) it is
refused: not saved, not logged, not attached, not thumbnailed.

## What was added (existing prototype is unchanged)
The prototype had no upload feature, so the upload entry points were added together with the guard. All existing routes and screens behave as before.

| Entry point | Endpoint | UI |
|---|---|---|
| Documents (incl. claim supporting images) | `POST /api/documents/upload?purpose=claim_support\|employment_document\|other` | new **Documents** page |
| KYC image | `POST /api/identity/kyc/upload` | card at the bottom of **Identity Verification** |
| Issue attachment | `POST /api/issues/<id>/attachments` | **Attachments** card on a tracked issue |
| View / list / delete own uploads | `GET /api/uploads/<id>/file`, `GET /api/uploads`, `POST /api/uploads/<id>/delete` | thumbnails + Delete |

All three upload routes are served by one function, `serve_upload()` in `app.py`, which is the only code path that can create a stored upload.

## Pipeline (server)
1. Authenticate (session cookie) **before reading the body**; authorise (issue attachments: employee who owns the issue); CSRF header `X-P360-Upload: 1` + Origin check; per-user rate limit; per-user quota.
2. Content-Length required; refuse over-size **without reading the body**; read with a socket timeout.
3. `image_scan.scan_upload()`:
   - magic-byte sniff (PNG / JPEG / WebP only; client MIME and filename are ignored); Pillow decode + `verify()`; size, pixel and dimension limits (decompression bombs rejected); animated images rejected.
   - sanitise: EXIF rotation applied, then re-drawn into a fresh RGB image (all EXIF/ICC/XMP/text metadata dropped, alpha flattened). OCR and storage use these same sanitised pixels.
   - OCR with local **Tesseract** (`tesseract stdin stdout`, image piped through stdin: **no temp file is ever created**). Passes: normal, sparse, inverted (dark mode), and 90/270/180° rotations; small images are enlarged, huge ones reduced.
   - `sensitive_detect.analyse()` on the recognised text (kept only in local variables; never returned or logged).
4. Outcome: `clean` → store; `blocked` / `uncertain` / `unavailable` / `invalid` → refuse. Nothing is written for any refusal.
5. Accepted images are stored **encrypted** (Fernet, same master key as PAN) under a random name, mode `0600`, in a `0700` directory that is never served statically; written to a temp name then atomically renamed, with cleanup on any exception. Download only via an authenticated, owner-only endpoint.
6. Audit log records only: actor, route, outcome, reason code, category names (e.g. `route=documents; outcome=blocked; reason=OTP_DETECTED; categories=otp`). Never the value, OCR text or filename. `log_message` stays disabled; unexpected exceptions return a generic message.

## Detection
Contextual, not "every 6-digit number": a 4-8 digit code (also `123 456`, `123-456`, `12-34-56`, OCR look-alikes such as `O`/`l`) counts when it sits near OTP wording (OTP, one-time password, verification / authentication / security / login code, passcode, 2FA, "do not share", "expires in N minutes"...).
Wording with **no readable code** (or two independent weak hints) → *uncertain* → safe warning asking for a redacted image.
Also: Aadhaar (Verhoeff checksum or keyword), PAN, UAN, bank account (keyword / IFSC), card numbers (Luhn), PIN/CVV/password statements.
Order numbers, receipts, amounts, dates and years are not flagged.

## Configuration (environment variables)
| Variable | Default | Meaning |
|---|---|---|
| `P360_FAIL_CLOSED` | `1` | `0` = accept images that could not be verified (OCR down/timeout/ambiguous). Per route: `P360_FAIL_CLOSED_DOCUMENTS`, `_KYC`, `_ISSUE_ATTACHMENT`. A detected OTP is **always** blocked. |
| `P360_SCAN_ALLOW` | empty | Comma list of identifier categories to allow, from `aadhaar,pan,uan,bank_account,card`. OTP / credential / uncertain can never be allowed. |
| `P360_MAX_IMAGE_BYTES` / `_PIXELS` / `_SIDE` | 5 MB / 25 MP / 10000 px | Size limits |
| `P360_OCR_TIMEOUT` | 25 s | Whole-scan time budget |
| `P360_OCR_CONCURRENCY` | 2 | Parallel scans; extra requests wait 10 s then fail closed |
| `P360_UPLOADS_PER_MINUTE` | 10 | Per-user attempts (blocked attempts count) |
| `P360_MAX_UPLOADS_PER_USER` | 200 | Stored uploads per user |
| `P360_TESSERACT` | `tesseract` on PATH | Path to the OCR binary |
| `PROVIDENT360_UPLOADS` | `./uploads_private` | Private upload directory |

## Setup and run
```
pip install cryptography Pillow
sudo apt-get install tesseract-ocr tesseract-ocr-eng     # macOS: brew install tesseract   Windows: UB-Mannheim installer, add to PATH
python app.py                                            # http://localhost:8000   (prints a warning if OCR is not available)
python Test_app.py                                       # original 26 tests
python Test_upload_guard.py                              # 33 feature tests (real server + real OCR, synthetic images)
python tests/make_synthetic_images.py                    # regenerate synthetic test images (fake codes, fake people)
pip install playwright && playwright install chromium && python tests/e2e_ui.py   # optional browser end-to-end check
```
Without Pillow or Tesseract the rest of the app works unchanged and **image uploads are refused** (fail closed).
Demo logins: `asha@demo.test` (employee), `hr@sunrise.demo.test` (employer); password `demo1234`.

## User flow
Drag-and-drop, clipboard paste (Ctrl/Cmd+V) and the file picker all call one function (`UP.submit`). A progress bar shows upload and "Checking image for sensitive information…".
If blocked, an accessible alert dialog (focus moves to it) shows the required warning with three actions: redact and upload again, choose a different document, cancel.
The built-in redaction tool (mouse, touch **or keyboard**) paints opaque black boxes onto a **new flattened canvas image** (original pixels replaced, no EXIF) which is uploaded and **re-scanned by the server**. The rejected original exists only in the user's own browser memory; the server never receives it again.

## Known limitations (please read)
- OCR is not perfect. Stylised, very large, very low-contrast, blurred, handwritten or non-Latin-digit codes, or a code in a photo of a screen at an angle, can be missed. A bare code with no wording nearby is deliberately not flagged. This reduces risk; it does not guarantee absence of secrets.
- English wording only (Tesseract `eng`). Add language packs and keywords in `sensitive_detect.py` for others.
- PDFs, GIF, SVG and animated images are rejected because they cannot be scanned the same way.
- Memory: image bytes and OCR text live only in Python variables for the request; Python gives no guarantee they are zeroed. Nothing is claimed about secure deletion of storage media; no temp files are created, so there is nothing on disk to delete.
- Rate limiting and the OCR slot limit are per process (in memory). Behind several workers, add a shared limiter.
- Sign-in remains the prototype's demo-grade auth; serve behind HTTPS and set `PROVIDENT360_HTTPS=1` for secure cookies in any real deployment.
- Keep Pillow and Tesseract patched: they parse untrusted images.