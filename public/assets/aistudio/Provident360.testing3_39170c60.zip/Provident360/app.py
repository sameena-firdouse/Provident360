"""Provident360 demo server. Python standard library only (no pip install needed)."""
import hashlib, hmac, json, os, re, secrets, sqlite3, unicodedata
from difflib import SequenceMatcher
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import threading, time as _time
from collections import defaultdict, deque
try: import image_scan
except ImportError: image_scan = None      # uploads are refused (fail closed) until Pillow is installed

ROOT = Path(__file__).parent
def db_path(): return os.environ.get("PROVIDENT360_DB", str(ROOT / "provident360.db"))

SCHEMA = """
create table if not exists users(id integer primary key, email text unique not null, name text not null, role text not null check(role in ('employee','employer')), pw text not null);
create table if not exists sessions(token text primary key, user_id integer not null references users(id));
create table if not exists employers(id integer primary key, user_id integer unique not null references users(id), name text not null, establishment_id text unique);
create table if not exists employee_profiles(id integer primary key, user_id integer unique not null references users(id), demo_emp_id text, uan text);
create table if not exists employments(id integer primary key, employee_id integer not null references employee_profiles(id), employer_name text not null, establishment_id text, pf_member_id text not null, joining text, exit_date text, status text, unique(employee_id, pf_member_id));
create table if not exists employee_records(id integer primary key, employment_id integer not null references employments(id), month text not null, basic real, da real, pf_wages real, emp_contrib real, er_contrib real, passbook_emp real, passbook_er real, observed_ecr text, doc_ref text, updated_at text, unique(employment_id, month));
create table if not exists employer_records(id integer primary key, employer_id integer not null references employers(id), employee_name text not null, employee_ref text, uan text, pf_member_id text not null, month text not null, joining text, exit_date text, basic real, da real, pf_wages real, emp_epf real, er_epf real, eps real, ecr_status text not null, ecr_date text, ecr_ref text, trrn text, pay_status text, pay_date text, doc_ref text, version integer default 1, updated_at text, unique(employer_id, pf_member_id, month));
create table if not exists record_history(id integer primary key, record_id integer not null references employer_records(id), version integer, snapshot text, changed_at text);
create table if not exists reconciliations(id integer primary key, employee_id integer not null, employment_id integer not null references employments(id), month text not null, employer_record_id integer, status_label text, classification text, expected real, reported real, posted real, diff real, explanation text, updated_at text, unique(employment_id, month));
create table if not exists identity_employee(employee_id integer primary key references employee_profiles(id), legal_name text not null, dob text, pan_enc text, pan_idx text, pan_last4 text, updated_at text);
create table if not exists identity_employer(id integer primary key, employer_id integer not null references employers(id), pf_member_id text not null, employee_ref text, legal_name text not null, dob text, pan_enc text, pan_idx text, pan_last4 text, updated_at text, unique(employer_id, pf_member_id));
create table if not exists identity_cases(id integer primary key, record_id integer not null references identity_employer(id), employee_id integer not null, employer_id integer not null, field text not null, result text not null, status text not null default 'Open', sig text, detected_at text, updated_at text, notes text, evidence text, resolved_by text, resolved_at text, unique(record_id, field));
create table if not exists notifications(id integer primary key, user_id integer not null references users(id), case_id integer, message text not null, sig text, created_at text, is_read integer default 0, unique(user_id, case_id, sig));
create table if not exists audit_log(id integer primary key, actor text, action text, case_id integer, detail text, at text);
create table if not exists demo_contacts(id integer primary key, key text unique not null, name text not null, title text not null, organization text not null, email text not null, handles text);
create table if not exists issues(id integer primary key, user_id integer not null references users(id), employee_id integer not null references employee_profiles(id), category text not null, title text not null, description text, employment_id integer references employments(id), reconciliation_id integer, wage_month text, employer_name text, reference text, contact_key text, next_action text, follow_up_date text, status text not null default 'Open', dedupe_key text not null, created_at text, updated_at text);
create unique index if not exists ux_issue_active on issues(user_id, dedupe_key) where status not in ('Resolved','Closed');
create table if not exists issue_notes(id integer primary key, issue_id integer not null references issues(id), user_id integer not null, note text not null, created_at text);
create table if not exists uploads(id integer primary key, user_id integer not null references users(id), route text not null, purpose text, issue_id integer references issues(id), file_key text not null unique, mime text not null, size integer not null, created_at text);
create table if not exists issue_events(id integer primary key, issue_id integer not null references issues(id), actor text, event text not null, from_status text, to_status text, detail text, at text);
"""

class Bad(Exception):
    def __init__(self, msg, code=400): super().__init__(msg); self.code = code

def db():
    c = sqlite3.connect(db_path()); c.row_factory = sqlite3.Row
    c.execute("pragma foreign_keys=on"); return c
def init():
    c = db(); c.executescript(SCHEMA); migrate(c); seed(c); seed_identity(c); seed_contacts(c); c.commit(); c.close()
def migrate(c):
    # additive only: never drops or resets existing data
    if "issue_id" not in [r[1] for r in c.execute("pragma table_info(notifications)")]: c.execute("alter table notifications add column issue_id integer")
def now(): return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
def norm(s): return re.sub(r"[^a-z0-9]", "", (s or "").lower())
def mask(p): return "••••" + p[-4:] if p else ""
def hp(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100000).hex()
def chk(pw, h): return secrets.compare_digest(hp(pw, h.split("$")[0]), h)

# ---------- validation ----------
N, S, D, M = "n", "s", "d", "m"
ECR = ("Not submitted", "Submitted", "Corrected")
EMPLOYMENT = dict(employer_name=(S, 1), establishment_id=(S, 0), pf_member_id=(S, 1), joining=(D, 0), exit_date=(D, 0), status=(("Current", "Previous"), 0))
EREC = dict(employment_id=(N, 1), month=(M, 1), basic=(N, 0), da=(N, 0), pf_wages=(N, 0), emp_contrib=(N, 0), er_contrib=(N, 0),
            passbook_emp=(N, 0), passbook_er=(N, 0), observed_ecr=(ECR + ("Unknown",), 0), doc_ref=(S, 0))
RREC = dict(employee_name=(S, 1), employee_ref=(S, 0), uan=(S, 0), pf_member_id=(S, 1), month=(M, 1), joining=(D, 0), exit_date=(D, 0),
            basic=(N, 0), da=(N, 0), pf_wages=(N, 0), emp_epf=(N, 0), er_epf=(N, 0), eps=(N, 0), ecr_status=(ECR, 1), ecr_date=(D, 0),
            ecr_ref=(S, 0), trrn=(S, 0), pay_status=(("Unknown", "Pending", "Paid"), 0), pay_date=(D, 0), doc_ref=(S, 0))

def clean(d, spec):
    out = {}
    for k, (t, req) in spec.items():
        v = d.get(k); v = v.strip() if isinstance(v, str) else v
        if v in (None, ""):
            if req: raise Bad(f"{k.replace('_', ' ')} is required")
            out[k] = None; continue
        if t == N:
            try: v = float(v); assert 0 <= v < 1e9
            except Exception: raise Bad(f"{k.replace('_', ' ')} must be a non-negative number")
        elif t == D:
            try: datetime.strptime(str(v), "%Y-%m-%d")
            except Exception: raise Bad(f"{k.replace('_', ' ')} must be a date (YYYY-MM-DD)")
        elif t == M:
            if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", str(v)): raise Bad("wage month must look like 2024-03")
        elif isinstance(t, tuple):
            if v not in t: raise Bad(f"{k.replace('_', ' ')} must be one of: {', '.join(t)}")
        else: v = re.sub(r"[<>]", "", str(v))[:120]
        out[k] = v
    if out.get("joining") and out.get("exit_date") and out["exit_date"] < out["joining"]:
        raise Bad("exit date cannot be before joining date")
    return out

def ins(c, table, d):
    ks = list(d)
    return c.execute(f"insert into {table}({','.join(ks)}) values({','.join('?' * len(ks))})", [d[k] for k in ks]).lastrowid

# ---------- reconciliation engine ----------
def inr(m, e): return (not e["joining"] or m >= e["joining"][:7]) and (not e["exit_date"] or m <= e["exit_date"][:7])

def judge(e, m, rs, wk, em, others):
    notes, cls, label, exp, rep, post, diff, rid = [], None, "Not matched", None, None, None, None, None
    if len(rs) > 1:
        label, cls = "Needs review", "Duplicate record"
        notes.append("More than one employer record matches this PF Member ID, employer and month. Nothing was merged automatically.")
    elif not rs and wk:
        label, cls = "Needs review", "Needs review"
        notes.append("An employer record has this PF Member ID but a different establishment ID/name, so it was not matched automatically.")
    elif not rs:
        cls = "Missing record"
        notes.append("No employer ECR record matched for this wage month.")
    else:
        r = rs[0]; rid = r["id"]; rep = r["emp_epf"]
        label = "Submitted (employer-reported)" if r["ecr_status"] in ("Submitted", "Corrected") else "Employer reported"
        if r["pay_status"] == "Paid": label = "Payment reported"
        post = em["passbook_emp"] if em else None
        if post is not None: label = "Passbook credit recorded"
        wage = r["pf_wages"] if r["pf_wages"] is not None else (em["pf_wages"] if em else None)
        exp = round(min(wage, 15000) * 0.12, 2) if wage is not None else None
        notes.append(f"Employer-entered data, not verified by EPFO. ECR status: {r['ecr_status']}. Payment: {r['pay_status'] or 'Unknown'}.")
        if r["pay_status"] in ("Paid", "Pending") and post is None:
            cls = "Possible timing difference"; notes.append("Payment reported, but Passbook credit not verified. Passbook posting can lag behind payment.")
        elif post is not None and rep is not None and abs(post - rep) > 1:
            cls = "Amount mismatch"; notes.append("Passbook contribution differs from the employer-reported amount.")
        elif exp is not None and rep is not None and abs(exp - rep) > 1:
            cls = "Amount mismatch"; notes.append("Employer-reported amount differs from the estimate.")
        elif exp is None or rep is None:
            cls = "Needs review"; notes.append("Not enough information to estimate the expected amount.")
        else: cls = "No discrepancy detected"
        if exp is not None: notes.append("Expected is an estimate only (12% of PF wages up to the 15,000 ceiling); eligibility and exemptions are not applied.")
        if post is not None and rep is not None: diff = round(post - rep, 2)
        elif exp is not None and rep is not None: diff = round(rep - exp, 2)
    if not e["joining"]:
        notes.append("Joining date is missing for this employment.")
        if cls in (None, "No discrepancy detected"): cls, label = "Needs review", "Needs review"
    if cls != "Duplicate record":
        for f in others:
            if e["joining"] and f["joining"] and inr(m, e) and inr(m, f):
                cls, label = "Potential overlap", "Needs review"
                notes.append(f"Employment dates overlap with {f['employer_name']} in this month. Please review both records.")
    return dict(rid=rid, label=label, cls=cls, exp=exp, rep=rep, post=post, diff=diff, notes=" ".join(notes))

def reconcile(c, eid):
    emps = c.execute("select * from employments where employee_id=?", (eid,)).fetchall()
    c.execute("delete from reconciliations where employee_id=?", (eid,))
    for e in emps:
        strong, weak = {}, {}
        for r in c.execute("select r.*, p.name org, p.establishment_id est from employer_records r join employers p on p.id=r.employer_id where r.pf_member_id=?", (e["pf_member_id"],)):
            ok = (e["establishment_id"] and e["establishment_id"] == r["est"]) or norm(e["employer_name"]) == norm(r["org"])
            (strong if ok else weak).setdefault(r["month"], []).append(r)
        mine = {x["month"]: x for x in c.execute("select * from employee_records where employment_id=?", (e["id"],))}
        others = [f for f in emps if f["id"] != e["id"]]
        for m in sorted(set(mine) | set(strong) | set(weak)):
            j = judge(e, m, strong.get(m, []), weak.get(m, []), mine.get(m), others)
            c.execute("insert into reconciliations(employee_id,employment_id,month,employer_record_id,status_label,classification,expected,reported,posted,diff,explanation,updated_at) values(?,?,?,?,?,?,?,?,?,?,?,?)",
                      (eid, e["id"], m, j["rid"], j["label"], j["cls"], j["exp"], j["rep"], j["post"], j["diff"], j["notes"], now()))

def reconcile_pf(c, *pfs):
    q = ",".join("?" * len(pfs))
    for r in c.execute(f"select distinct employee_id from employments where pf_member_id in ({q})", pfs).fetchall(): reconcile(c, r[0])

# ---------- save operations (each one re-runs reconciliation) ----------
def save_employment(c, prof, d):
    v = clean(d, EMPLOYMENT)
    try: ins(c, "employments", {**v, "employee_id": prof["id"]})
    except sqlite3.IntegrityError: raise Bad("This PF Member ID is already saved on your account.", 409)
    reconcile(c, prof["id"]); rematch_employee(c, prof["id"]); c.commit()

def save_employee_record(c, prof, d):
    v = clean(d, EREC); v["employment_id"] = int(v["employment_id"])
    if not c.execute("select 1 from employments where id=? and employee_id=?", (v["employment_id"], prof["id"])).fetchone():
        raise Bad("Employment not found.", 404)
    try: ins(c, "employee_records", {**v, "updated_at": now()})
    except sqlite3.IntegrityError: raise Bad("You already saved a record for this employment and wage month.", 409)
    reconcile(c, prof["id"]); c.commit()

def save_employer_record(c, emp, d, rid=None):
    v = clean(d, RREC); v["pay_status"] = v["pay_status"] or "Unknown"; pfs = [v["pf_member_id"]]
    try:
        if rid:
            old = c.execute("select * from employer_records where id=? and employer_id=?", (rid, emp["id"])).fetchone()
            if not old: raise Bad("Record not found.", 404)
            c.execute("insert into record_history(record_id,version,snapshot,changed_at) values(?,?,?,?)", (rid, old["version"], json.dumps(dict(old)), now()))
            sets = ",".join(f"{k}=?" for k in v)
            c.execute(f"update employer_records set {sets}, version=version+1, updated_at=? where id=?", [*v.values(), now(), rid]); pfs.append(old["pf_member_id"])
        else: ins(c, "employer_records", {**v, "employer_id": emp["id"], "updated_at": now()})
    except sqlite3.IntegrityError:
        raise Bad("A record for this PF Member ID and wage month already exists. Edit it instead of adding a new one.", 409)
    reconcile_pf(c, *pfs); c.commit()


# ---------- identity verification (privacy-first) ----------
# PAN is encrypted at rest (Fernet) and compared through a keyed hash (HMAC "blind index"), so the backend never
# needs to decrypt it and the browser only ever receives a masked value. Aadhaar is deliberately NOT collected.
from cryptography.fernet import Fernet
def _master():
    k = os.environ.get("PROVIDENT360_KEY")
    if k: return k.encode()
    f = ROOT / ".secrets" / "key"
    if not f.exists():
        f.parent.mkdir(exist_ok=True); f.write_bytes(Fernet.generate_key())
        try: os.chmod(f, 0o600)
        except OSError: pass
    return f.read_bytes().strip()
def enc(v): return Fernet(_master()).encrypt(v.encode()).decode()
def bidx(v): return hmac.new(hashlib.sha256(b"idx" + _master()).digest(), v.encode(), "sha256").hexdigest()
def audit(c, actor, action, case_id=None, detail=""):
    c.execute("insert into audit_log(actor,action,case_id,detail,at) values(?,?,?,?,?)", (actor, action, case_id, detail, now()))

IDENT = dict(legal_name=(S, 1), dob=(D, 1), pan=(S, 0))
EIDENT = dict(pf_member_id=(S, 1), legal_name=(S, 1), dob=(D, 0), pan=(S, 0), employee_ref=(S, 0))
SECRET_LIKE = re.compile(r"[A-Z]{5}\d{4}[A-Z]|\b\d{4}\s?\d{4}\s?\d{4}\b")

def id_fields(v):
    if v.get("dob") and not ("1900-01-01" <= v["dob"] <= datetime.now().strftime("%Y-%m-%d")): raise Bad("date of birth is not a valid past date")
    pan = (v.pop("pan", None) or "").upper().replace(" ", "")
    if pan and not re.fullmatch(r"[A-Z]{5}\d{4}[A-Z]", pan): raise Bad("PAN format is invalid (expected 5 letters, 4 digits, 1 letter)")
    v.update(pan_enc=enc(pan) if pan else None, pan_idx=bidx(pan) if pan else None, pan_last4=pan[-4:] if pan else None)
    return v

def save_id_employee(c, prof, d, actor="system"):
    v = id_fields(clean(d, IDENT)); v.update(employee_id=prof["id"], updated_at=now()); ks = list(v)
    c.execute(f"insert into identity_employee({','.join(ks)}) values({','.join('?' * len(ks))}) on conflict(employee_id) do update set " + ",".join(f"{k}=excluded.{k}" for k in ks if k != "employee_id"), [v[k] for k in ks])
    audit(c, actor, "employee_identity_saved", detail="fields: legal_name, dob, pan"); rematch_employee(c, prof["id"]); c.commit()

def save_id_employer(c, emp, d, actor="system"):
    v = id_fields(clean(d, EIDENT)); v.update(employer_id=emp["id"], updated_at=now()); ks = list(v)
    c.execute(f"insert into identity_employer({','.join(ks)}) values({','.join('?' * len(ks))}) on conflict(employer_id,pf_member_id) do update set " + ",".join(f"{k}=excluded.{k}" for k in ks if k not in ("employer_id", "pf_member_id")), [v[k] for k in ks])
    rid = c.execute("select id from identity_employer where employer_id=? and pf_member_id=?", (emp["id"], v["pf_member_id"])).fetchone()[0]
    audit(c, actor, "employer_identity_saved", detail=f"record {rid}"); match_record(c, rid); c.commit()

def nname(s): return " ".join(unicodedata.normalize("NFKC", s or "").casefold().split())
def compare(e, r):
    """e = employee identity row (or None), r = employer identity row. Returns one result per field."""
    out = []
    for f, key in (("Legal name", "legal_name"), ("Date of birth", "dob"), ("PAN", "pan_idx")):
        a, b = (e[key] if e else None), r[key]
        if f == "Legal name": a, b = nname(a), nname(b)
        if not a and not b: res, why = "NOT PROVIDED", "Neither party provided this field."
        elif not a or not b: res, why = "UNABLE TO COMPARE", "Only one party has provided this field so far."
        elif a == b: res, why = "MATCH", "Values agree."
        elif f == "Legal name" and SequenceMatcher(None, a, b).ratio() >= 0.85: res, why = "PENDING REVIEW", "The names are very similar; this may be a spelling difference."
        else: res, why = "MISMATCH", "The two records hold different values."
        out.append(dict(field=f, result=res, why=why, basis=bidx(f"{f}|{a}|{b}") if res in ("MISMATCH", "PENDING REVIEW") else ""))
    return out

def link_employee(c, r):
    """Internal-ID link: same PF Member ID AND same employer (establishment ID or exact org name) on an employee's employment. Never by person name."""
    o = c.execute("select name, establishment_id from employers where id=?", (r["employer_id"],)).fetchone()
    hits = {x["employee_id"] for x in c.execute("select * from employments where pf_member_id=?", (r["pf_member_id"],))
            if (x["establishment_id"] and x["establishment_id"] == o["establishment_id"]) or norm(x["employer_name"]) == norm(o["name"])}
    return hits.pop() if len(hits) == 1 else None

def match_record(c, rid):
    r = c.execute("select * from identity_employer where id=?", (rid,)).fetchone(); eid = link_employee(c, r) if r else None
    if eid is None: return
    e = c.execute("select * from identity_employee where employee_id=?", (eid,)).fetchone()
    users = [x[0] for x in c.execute("select user_id from employee_profiles where id=? union select user_id from employers where id=?", (eid, r["employer_id"]))]
    for x in compare(e, r):
        case = c.execute("select * from identity_cases where record_id=? and field=?", (rid, x["field"])).fetchone()
        if x["result"] in ("MISMATCH", "PENDING REVIEW"):
            if case and case["sig"] == x["basis"]: continue            # unchanged mismatch: no new case, no new notification
            if case:
                c.execute("update identity_cases set result=?,sig=?,status='Open',updated_at=?,resolved_by=null,resolved_at=null,employee_id=? where id=?", (x["result"], x["basis"], now(), eid, case["id"])); cid = case["id"]
            else:
                cid = c.execute("insert into identity_cases(record_id,employee_id,employer_id,field,result,sig,detected_at,updated_at) values(?,?,?,?,?,?,?,?)", (rid, eid, r["employer_id"], x["field"], x["result"], x["basis"], now(), now())).lastrowid
            audit(c, "system", "case_opened_or_changed", cid, x["field"])
            for u in users:
                c.execute("insert or ignore into notifications(user_id,case_id,message,sig,created_at) values(?,?,?,?,?)", (u, cid, f"{x['field']} differs between the employee's and employer's records. Please sign in to Identity Verification to review it.", x["basis"], now()))
        elif x["result"] == "MATCH" and case and case["status"] != "Resolved":
            c.execute("update identity_cases set status='Resolved',result='MATCH',resolved_by='System (records now match)',resolved_at=?,updated_at=? where id=?", (now(), now(), case["id"]))
            audit(c, "system", "case_auto_resolved", case["id"], x["field"])

def rematch_employee(c, eid):
    for r in c.execute("select id, employer_id, pf_member_id from identity_employer").fetchall():
        if link_employee(c, r) == eid: match_record(c, r["id"])

STEPS = {"Legal name": "Check the name on a PAN card or government ID, then correct whichever record is wrong.",
         "Date of birth": "Check the date of birth on an official document, then correct whichever record is wrong.",
         "PAN": "Re-enter the PAN carefully from the card (do not paste it into notes), then correct whichever record is wrong."}
CAUSES = {"Legal name": "Spelling variation, initials or a typing error.", "Date of birth": "Day/month swapped or a typing error.", "PAN": "A typing error or an outdated number."}

def id_records(c, user):
    if user["role"] == "employer":
        emp = c.execute("select * from employers where user_id=?", (user["id"],)).fetchone()
        rows = c.execute("select * from identity_employer where employer_id=? order by id", (emp["id"],)).fetchall(); me = "employer"
    else:
        prof = c.execute("select * from employee_profiles where user_id=?", (user["id"],)).fetchone()
        rows = [r for r in c.execute("select * from identity_employer order by id") if link_employee(c, r) == prof["id"]]; me = "employee"
    out = []
    for r in rows:
        eid = link_employee(c, r); e = c.execute("select * from identity_employee where employee_id=?", (eid,)).fetchone() if eid else None
        o = c.execute("select name from employers where id=?", (r["employer_id"],)).fetchone()
        cases = {k["field"]: k for k in c.execute("select * from identity_cases where record_id=?", (r["id"],))}
        fields = []
        for x in compare(e, r):
            f, cs = x["field"], cases.get(x["field"])
            def val(row, own):
                if not row: return None
                if f == "Legal name": return row["legal_name"]
                if f == "Date of birth": return row["dob"] if (own and row["dob"]) else (row["dob"][:4] + "-••-••" if row["dob"] else None)
                return "XXXXXX" + row["pan_last4"] if row["pan_last4"] else None
            flagged = x["result"] in ("MISMATCH", "PENDING REVIEW")
            fields.append(dict(field=f, result=x["result"], explanation=x["why"], employee_value=val(e, me == "employee"), employer_value=val(r, me == "employer"),
                               case_id=cs["id"] if cs else None, status=cs["status"] if cs else None, detected=cs["detected_at"] if cs else None, notes=cs["notes"] if cs else None,
                               evidence=cs["evidence"] if cs else None, resolved_by=cs["resolved_by"] if cs else None, resolved_at=cs["resolved_at"] if cs else None,
                               possible_cause=CAUSES[f] if flagged or (cs and cs["status"] != "Resolved") else None, next_steps=STEPS[f] if flagged or (cs and cs["status"] != "Resolved") else None))
        st = [f["status"] for f in fields if f["status"]]
        summary = "Unable to compare" if not e else "Discrepancy" if any(s in ("Open", "In review") for s in st) else "Resolved" if st else "Matched"
        out.append(dict(id=r["id"], organization=o["name"], pf_masked=mask(r["pf_member_id"]), employee_name=r["legal_name"], summary=summary, linked=eid is not None, fields=fields, updated=r["updated_at"]))
    return out

def case_for(c, user, cid):
    cs = c.execute("select * from identity_cases where id=?", (cid,)).fetchone()
    if user["role"] == "employer": ok = cs and c.execute("select 1 from employers where id=? and user_id=?", (cs["employer_id"], user["id"])).fetchone()
    else: ok = cs and c.execute("select 1 from employee_profiles where id=? and user_id=?", (cs["employee_id"], user["id"])).fetchone()
    if not ok: raise Bad("Not found.", 404)
    return cs

def identity_api(c, user, method, path, body):
    if not user: raise Bad("Please sign in.", 401)
    who = f"{user['role']}:{user['id']}"
    if path == "/api/notifications":
        return 200, {"notifications": [dict(id=n["id"], message=n["message"], created=n["created_at"], read=bool(n["is_read"]), case_id=n["case_id"]) for n in c.execute("select * from notifications where user_id=? order by id desc limit 50", (user["id"],))]}, None
    if path == "/api/notifications/read" and method == "POST":
        c.execute("update notifications set is_read=1 where user_id=?", (user["id"],)); c.commit(); return 200, {"ok": True}, None
    if path == "/api/identity/records": return 200, {"role": user["role"], "records": id_records(c, user)}, None
    if path == "/api/identity/me":
        need(user, "employee"); prof = c.execute("select * from employee_profiles where user_id=?", (user["id"],)).fetchone()
        if method == "POST": save_id_employee(c, prof, body, who); return 200, {"ok": True}, None
        e = c.execute("select * from identity_employee where employee_id=?", (prof["id"],)).fetchone()
        return 200, {"profile": {"legal_name": e["legal_name"], "dob": e["dob"], "pan": "XXXXXX" + e["pan_last4"] if e["pan_last4"] else None} if e else None}, None
    if path == "/api/identity/employer-record" and method == "POST":
        need(user, "employer"); save_id_employer(c, c.execute("select * from employers where user_id=?", (user["id"],)).fetchone(), body, who); return 200, {"ok": True}, None
    if path == "/api/identity/delete" and method == "POST":      # erasure of identity data; PAN/name/DOB removed, audit entry keeps no values
        if user["role"] == "employee":
            prof = c.execute("select * from employee_profiles where user_id=?", (user["id"],)).fetchone()
            c.execute("delete from identity_employee where employee_id=?", (prof["id"],)); audit(c, who, "employee_identity_deleted"); rematch_employee(c, prof["id"])
        else:
            emp = c.execute("select * from employers where user_id=?", (user["id"],)).fetchone()
            rid = int(body.get("id") or 0)
            if not c.execute("select 1 from identity_employer where id=? and employer_id=?", (rid, emp["id"])).fetchone(): raise Bad("Not found.", 404)
            c.execute("delete from notifications where case_id in (select id from identity_cases where record_id=?)", (rid,))
            c.execute("delete from identity_cases where record_id=?", (rid,)); c.execute("delete from identity_employer where id=?", (rid,)); audit(c, who, "employer_identity_deleted", detail=f"record {rid}")
        c.commit(); return 200, {"ok": True}, None
    if path.startswith("/api/identity/cases/") and method == "POST":
        cs = case_for(c, user, int(path.rsplit("/", 1)[1])); act = body.get("action")
        notes, ev = clean(body, dict(notes=(S, 0), evidence=(S, 0))).values()
        if any(t and SECRET_LIKE.search(t.upper()) for t in (notes, ev)): raise Bad("Notes and evidence must not contain PAN or Aadhaar numbers. Describe the document instead.")
        if act == "review": c.execute("update identity_cases set status='In review',notes=coalesce(?,notes),evidence=coalesce(?,evidence),updated_at=? where id=? and status!='Resolved'", (notes, ev, now(), cs["id"]))
        elif act == "note": c.execute("update identity_cases set notes=coalesce(?,notes),evidence=coalesce(?,evidence),updated_at=? where id=?", (notes, ev, now(), cs["id"]))
        elif act == "resolve":
            if body.get("confirm") not in (True, "true", "on"): raise Bad("Please confirm that you have checked the evidence before resolving.")
            c.execute("update identity_cases set status='Resolved',notes=coalesce(?,notes),evidence=coalesce(?,evidence),resolved_by=?,resolved_at=?,updated_at=? where id=?", (notes, ev, f"{user['name']} ({user['role']})", now(), now(), cs["id"]))
        else: raise Bad("Unknown action.")
        audit(c, who, "case_" + act, cs["id"], cs["field"]); c.commit(); return 200, {"ok": True}, None
    raise Bad("Not found.", 404)

def seed_identity(c):
    a = c.execute("select * from users where email='asha@demo.test'").fetchone()
    if c.execute("select 1 from identity_employer").fetchone() or not a: return
    prof = c.execute("select * from employee_profiles where user_id=?", (a["id"],)).fetchone()
    e1 = c.execute("select * from employers where establishment_id='DEMOTN0001'").fetchone(); e2 = c.execute("select * from employers where establishment_id='DEMOKA0002'").fetchone()
    if not (e1 and e2): return
    save_id_employee(c, prof, dict(legal_name="Asha Demo", dob="1995-06-15", pan="ABCDE1234F"))      # synthetic
    save_id_employer(c, e1, dict(pf_member_id=PF_A, legal_name="Asha  DEMO", dob="1995-06-15", pan="ABCDE1234F"))   # all fields match
    save_id_employer(c, e2, dict(pf_member_id=PF_B, legal_name="Asha Demoo", dob="1995-06-16"))                      # name similar, DOB differs, PAN missing

# ---------- Issue Resolution & Contact Assistant ----------
# Guidance is built on the server from the signed-in employee's own records only. Contacts are FICTIONAL demo personas.
# Adding an issue only saves it inside Provident360: it does not contact an employer, send email or file a grievance.
def grievance_url():
    u = os.environ.get("PROVIDENT360_GRIEVANCE_URL", "https://epfigms.gov.in/").strip()
    return u if u.startswith("https://") else "https://epfigms.gov.in/"

ISSUE_STATUS = ("Open", "Under Review", "Waiting for Employer", "Waiting for Employee", "Escalated", "Resolved", "Closed")
ACTIVE_NOT = ("Resolved", "Closed")
DEMO_CONTACTS = [
    ("hr", "Ananya Rao", "HR Manager", "ABC Technologies (Demo)", "hr.demo@example.com",
     "Employee personal-detail corrections, joining/exit records and organizational employee records."),
    ("payroll", "Rahul Mehta", "Payroll & PF Officer", "ABC Technologies (Demo)", "payroll.demo@example.com",
     "Employer-side contribution records, ECR status, challan references and payroll questions."),
    ("coordinator", "Priya Nair", "Grievance Coordinator", "Provident360 Demo Support", "support.demo@example.com",
     "Helps organize evidence, follow-ups and neutral query drafts."),
]
DEMO_ORG = "ABC Technologies (Demo)"
NO_PHONE = "Demo contact — no real phone number"

def seed_contacts(c):
    for k, n, t, o, e, h in DEMO_CONTACTS:
        c.execute("insert or ignore into demo_contacts(key,name,title,organization,email,handles) values(?,?,?,?,?,?)", (k, n, t, o, e, h))

def contact_out(c, key):
    r = c.execute("select * from demo_contacts where key=?", (key,)).fetchone()
    if not r: return None
    return dict(key=r["key"], name=r["name"], title=r["title"], organization=r["organization"], email=r["email"], handles=r["handles"], phone=NO_PHONE,
                label="SAMPLE / DEMO contact — fictional persona, not verified, not an EPFO contact")

CATS = [
    ("contribution_mismatch", "PF contribution mismatch", "Expected and reported amounts differ.", "⚖️"),
    ("ecr_not_submitted", "ECR not submitted", "Employer submission status is missing or pending.", "📄"),
    ("challan_not_generated", "ECR submitted, challan not generated", "Submission and challan/payment status need checking.", "🧾"),
    ("payment_not_reflected", "Payment not reflected", "Payment evidence and individual passbook credit status need checking.", "💳"),
    ("identity_mismatch", "UAN, KYC or personal details mismatch", "Employee and employer records need verification.", "🪪"),
    ("claim_transfer_delay", "Claim or transfer delay", "Claim or transfer status has not been updated.", "⏳"),
    ("employment_overlap", "Employment overlap or missing service period", "Employment dates or service history may need review.", "🗓️"),
    ("other", "Other PF issue", "Describe an issue that is not listed above.", "💬"),
]
CAT_TITLE = {k: t for k, t, _, _ in CATS}

def rtags(r):
    t, cl = [], r["classification"]
    if cl == "Amount mismatch": t.append("contribution_mismatch")
    if cl == "Missing record" or r["ecr_status"] == "Not submitted": t.append("ecr_not_submitted")
    if r["employer_record_id"] and r["ecr_status"] in ("Submitted", "Corrected") and not r["trrn"]: t.append("challan_not_generated")
    if r["employer_record_id"] and r["pay_status"] in ("Paid", "Pending") and r["posted"] is None: t.append("payment_not_reflected")
    if cl == "Potential overlap": t.append("employment_overlap")
    return t

def inr_money(v): return None if v is None else f"₹{v:,.2f}"
def months_overlap(a, b):
    if not (a["joining"] and b["joining"]): return False
    a_end, b_end = (a["exit_date"] or "9999-12-31")[:7], (b["exit_date"] or "9999-12-31")[:7]
    return a["joining"][:7] <= b_end and b["joining"][:7] <= a_end

# category -> guidance. "steps"/"docs" are plain text; the message body is built in build_body().
GUIDE = {
 "contribution_mismatch": dict(contact="payroll", also=["coordinator"], base="Worth checking",
  explain="The contribution amount you expected differs from what the employer reported or what your passbook shows. Expected amounts in Provident360 are estimates (12% of PF wages up to the 15,000 ceiling) and depend on applicable rules, so a difference is a prompt to check, not a finding about anyone.",
  why="Employer payroll/PF officers hold the wage and contribution workings for a wage month.",
  steps=["Pick the wage month and compare your payslip, the PF wages used, the employer-reported contribution and any passbook entry you have.",
         "Note exactly which figures differ (for example PF wages, employee share, employer share). Differences often come from wage definitions, timing or data-entry errors.",
         "Send the message below to your employer's payroll / PF team and ask how the figure was calculated and whether a correction is needed.",
         "Save any reply, reference number and date in your tracked issue notes.",
         "If it is still unresolved after the employer-side steps, use the official EPFiGMS grievance portal."],
  docs=["Payslip for the wage month", "Passbook entry for the month (if available)", "Appointment letter or wage structure (if wages changed)", "Any earlier correspondence with the employer"],
  next_action="Compare payslip, PF wages and passbook for the wage month, then message payroll."),
 "ecr_not_submitted": dict(contact="payroll", also=["coordinator"], base="Worth checking",
  explain="Provident360 may show no ECR for a wage month, or an employer-entered status of 'Not submitted'. 'Not present in Provident360' only means the employer has not entered a record here; it is not independent proof that nothing was submitted to EPFO.",
  why="The Payroll & PF officer files and tracks the monthly ECR.",
  steps=["Confirm the wage month and that you have a payslip for it.",
         "Ask your employer's payroll / PF officer for the ECR submission status for that month (submitted, pending or corrected) and the acknowledgement, if any.",
         "Keep any acknowledgement or reply and record it in your tracked issue.",
         "Check again after the employer responds; the employer can enter or correct the record in Provident360.",
         "If it remains unclear after reasonable follow-up, consider the official EPFiGMS grievance portal."],
  docs=["Payslip for the wage month", "Passbook / member account view for nearby months (if available)", "Earlier messages with payroll"],
  next_action="Ask payroll for the ECR submission status for the wage month."),
 "challan_not_generated": dict(contact="payroll", also=["coordinator"], base="Worth checking",
  explain="An ECR can be submitted without a challan/payment reference being available yet. Provident360 does not generate or verify challans; it only shows what the employer entered.",
  why="Payroll/PF officers know the ECR processing status and any challan (TRRN) reference for a month.",
  steps=["Confirm the wage month and what Provident360 shows for ECR status and any challan/TRRN reference.",
         "Ask the payroll / PF officer to confirm the ECR processing status and share the challan/TRRN or payment reference if one exists.",
         "Do not assume a challan exists until the employer provides a reference; record any reference you receive.",
         "Follow up if no response; keep dates of each request.",
         "If still unresolved after employer-side steps, use the official EPFiGMS grievance portal."],
  docs=["ECR acknowledgement or reference (if shared)", "Payslip for the wage month", "Any payment confirmation the employer gave you"],
  next_action="Ask payroll for ECR processing status and any challan/TRRN reference."),
 "payment_not_reflected": dict(contact="payroll", also=["coordinator"], base="Worth checking",
  explain="Three different things are often mixed up: the employer saying a payment was made, evidence of that payment (a reference), and an actual credit in your own passbook. A demo status alone never confirms a credit, and passbook posting can lag behind payment.",
  why="Payroll/PF officers can share the payment reference and date for the month.",
  steps=["Check the payment status and reference the employer entered for the wage month.",
         "Check your own passbook for an entry for that wage month (credits can appear later than payment).",
         "Ask payroll for the payment reference/date and confirm which wage month it covers.",
         "If a reasonable time has passed with no passbook entry, follow up and keep all references in your notes.",
         "If still unresolved after employer-side steps, use the official EPFiGMS grievance portal."],
  docs=["Payment reference or confirmation from the employer (if any)", "Passbook screenshot or entry for the wage month (no full IDs)", "Payslip for the wage month"],
  next_action="Check the passbook for the wage month, then ask payroll for the payment reference."),
 "identity_mismatch": dict(contact="hr", also=["coordinator"], base="Worth checking",
  explain="Your details and the employer's record differ for at least one field. Differences are often spelling or typing variations. Provident360 never changes identity data automatically, and it only shows masked values.",
  why="HR holds employee personal-detail and joining/exit records and can start the correction.",
  steps=["Check which field is flagged (see below) against the original document.",
         "Verify the original identity document yourself; never share full ID numbers in messages or notes.",
         "Ask HR to review the field and confirm which record needs correcting, using the authorized correction process.",
         "Record any reference HR gives you; the correction itself must be made through the proper channel.",
         "If still unresolved, consider the official EPFiGMS grievance portal."],
  docs=["Original identity document for the flagged field (keep it with you; do not paste numbers)", "Appointment letter or other employer record showing the detail", "Any earlier correspondence about the correction"],
  next_action="Verify the flagged field against your original document, then ask HR to review."),
 "claim_transfer_delay": dict(contact="coordinator", also=["hr"], base="For information",
  explain="Provident360 does not currently hold claim or transfer records, so it cannot show a status. Check the status and reference number in your official EPFO member account or the relevant portal.",
  why="The grievance coordinator helps organize your evidence and follow-ups; HR can help where a former or current employer's attestation is involved.",
  steps=["Find your claim or transfer reference number in your official account or portal and note its latest status and date.",
         "If the status looks stalled, ask the relevant employer (for example for attestation or exit-date details) or use the official support channel that applies to your claim type.",
         "Do not rely on any processing time you have not seen on an official page.",
         "Record the reference, status, date and any reply in your tracked issue.",
         "If it remains unresolved, use the official EPFiGMS grievance portal."],
  docs=["Claim or transfer reference number", "Screenshot or note of the current status and date (no full IDs)", "Exit/joining details of the relevant employer"],
  next_action="Check the status and reference number in your official account."),
 "employment_overlap": dict(contact="hr", also=["coordinator"], base="Worth checking",
  explain="Overlapping months alone do not prove an error: compare the actual joining and exit dates. A gap or an overlap can come from a missing exit date, a typing error or a legitimate handover.",
  why="HR holds joining and exit records and can issue or correct them.",
  steps=["Review the employment dates shown below against your own records.",
         "Gather appointment, relieving or experience letters for each employer.",
         "Ask HR of the relevant employer to confirm the joining/exit dates they hold and correct them if needed.",
         "Update your own employment entry in Provident360 once dates are confirmed.",
         "If unresolved, consider the official EPFiGMS grievance portal."],
  docs=["Appointment letter(s)", "Relieving / experience letter(s)", "Payslips around the joining or exit month"],
  next_action="Compare actual joining/exit dates with your letters, then ask HR."),
 "other": dict(contact="coordinator", also=[], base="For information",
  explain="Describe what you are seeing. Provident360 will not draw a conclusion without enough information; it can help you organize notes and a neutral message.",
  why="The grievance coordinator helps organize evidence, follow-ups and neutral drafts for issues that do not fit another category.",
  steps=["Describe the issue in a few sentences, with dates and any reference numbers you already have.",
         "Decide whether it is employer-side (payroll or HR) or an official-portal matter, and contact accordingly.",
         "Save the issue to your tracking list and record each reply.",
         "Use the official EPFiGMS grievance portal if it cannot be resolved."],
  docs=["Any relevant documents you already hold", "Dates and reference numbers"],
  next_action="Write down what happened, with dates and references."),
}

def text_in(v, label, mx, req=False, strict=True):
    v = re.sub(r"[<>]", "", v.strip()) if isinstance(v, str) else ""
    if req and not v: raise Bad(f"{label} is required")
    if len(v) > mx: raise Bad(f"{label} must be {mx} characters or fewer")
    if v and (SECRET_LIKE.search(v.upper()) or re.search(r"(?<!\d)\d{12}(?!\d)", v) or (strict and re.search(r"\d{9,18}", v))):
        raise Bad(f"{label} must not contain PAN, Aadhaar, UAN or bank account numbers. Describe the document instead.")
    return v or None

def issue_facts(c, prof, user, cat, body):
    """Return (facts dict, 'what Provident360 shows' lines, related-row or None). Own records only."""
    rid = body.get("reconciliation_id"); r = None
    if rid not in (None, ""):
        try: rid = int(rid)
        except (TypeError, ValueError): raise Bad("Related record is invalid.")
        rows = c.execute(DETAIL + " and x.id=?", (prof["id"], rid)).fetchall()
        if not rows: raise Bad("Related record not found.", 404)
        r = rows[0]
    f = dict(name=user["name"], employer=None, month=None, pf_tail=None, reported=None, expected=None, posted=None, ecr_ref=None, trrn=None, pay_status=None, ecr_status=None)
    lines = []
    if r:
        f.update(employer=r["employer_name"], month=r["month"], pf_tail=r["pf_member_id"][-4:], reported=r["reported"], expected=r["expected"], posted=r["posted"],
                 ecr_ref=r["ecr_ref"], trrn=r["trrn"], pay_status=r["pay_status"], ecr_status=r["ecr_status"])
        lines.append(f"Related record: {r['employer_name']}, wage month {r['month']} (PF Member ID ending {f['pf_tail']}).")
        if cat in ("contribution_mismatch", "payment_not_reflected", "ecr_not_submitted", "challan_not_generated"):
            lines.append("Employer-reported employee contribution: " + (inr_money(r["reported"]) or "not available") + ". Estimate of expected amount: " + (inr_money(r["expected"]) or "not available") + " (estimate only).")
            lines.append("Passbook credit: " + (inr_money(r["posted"]) + " (your entry)." if r["posted"] is not None else "not verified in Provident360."))
        if cat in ("ecr_not_submitted", "challan_not_generated", "payment_not_reflected"):
            if r["employer_record_id"]:
                lines.append(f"Employer-entered ECR status: {r['ecr_status']}. Challan/TRRN reference: {'entered by employer' if r['trrn'] else 'none entered'}. Payment status: {r['pay_status'] or 'Unknown'} (employer-entered, not EPFO-verified).")
            else:
                lines.append("No employer ECR record for this wage month is present in Provident360. This does not independently confirm that nothing was submitted.")
        lines.append("Classification in Provident360: " + (r["classification"] or "n/a") + ". This is a prompt to check, not a finding.")
    elif cat in ("contribution_mismatch", "ecr_not_submitted", "challan_not_generated", "payment_not_reflected"):
        lines.append("No related monthly record selected. You can still save a manual issue; unknown details will appear as [placeholders] in the message.")
    if cat == "employment_overlap" or (cat == "claim_transfer_delay"):
        emps = c.execute("select * from employments where employee_id=? order by joining", (prof["id"],)).fetchall()
        if cat == "employment_overlap":
            for e in emps: lines.append(f"{e['employer_name']}: {e['joining'] or 'joining date missing'} to {e['exit_date'] or 'present/not entered'}.")
            ov = [(a["employer_name"], b["employer_name"]) for i, a in enumerate(emps) for b in emps[i + 1:] if months_overlap(a, b)]
            lines.append("Overlapping months between: " + "; ".join(f"{a} and {b}" for a, b in ov) + ". Compare actual dates before drawing any conclusion." if ov else "No overlapping months found in the dates entered.")
            if not emps: lines.append("No employments are saved yet.")
        else:
            lines.append("Provident360 does not hold claim or transfer records (not implemented in this prototype).")
    if cat == "identity_mismatch":
        cs = c.execute("select field,status,employer_id from identity_cases where employee_id=? and status!='Resolved' order by id", (prof["id"],)).fetchall()
        if cs:
            audit(c, f"employee:{user['id']}", "assistant_read_identity_case_fields", detail="field names only")
            for k in cs:
                o = c.execute("select name from employers where id=?", (k["employer_id"],)).fetchone()
                lines.append(f"Field needing review: {k['field']} (case {k['status']}), employer: {o['name'] if o else 'unknown'}. Values are not shown here.")
            f["fields"] = ", ".join(sorted({k["field"] for k in cs}))
        else: lines.append("No open identity mismatch is recorded in Provident360. If you see a mismatch elsewhere (for example in your UAN/KYC details), name the field in your description.")
    return f, lines, r

def build_message(cat, f, ref):
    P = lambda v, lbl: v if v not in (None, "") else f"[{lbl}]"
    mo, emp = P(f["month"], "Wage Month"), P(f["employer"], "Employer Name")
    pf = f"PF Member ID ending {f['pf_tail']}" if f["pf_tail"] else "PF Member ID [last 4 characters]"
    sign = "\n\nThank you for your help.\n\nRegards,\n" + (f["name"] or "[Your Name]")
    tail = f"\n\nReference details: {pf}; employer {emp}; wage month {mo}."
    if cat == "contribution_mismatch":
        sub = f"Query: PF contribution for wage month {mo}"; to = "Payroll & PF Officer"
        b = (f"I am writing to ask for clarification about the PF contribution for wage month {mo}.\n\n"
             f"In my records, the employer-reported employee contribution is {P(inr_money(f['reported']), 'Amount')}, my estimate of the expected amount is {P(inr_money(f['expected']), 'Expected Amount')} "
             f"(an estimate only; I understand the correct figure depends on applicable rules), and my passbook entry shows {P(inr_money(f['posted']), 'Passbook Amount, if available')}.\n\n"
             "I am not assuming an error; the difference may have an ordinary explanation such as timing, wage definition or data entry. Could you please share the wage and contribution details used for this month and let me know whether any correction is needed?" + tail)
    elif cat == "ecr_not_submitted":
        sub = f"Request: ECR submission status for wage month {mo}"; to = "Payroll & PF Officer"
        b = (f"Could you please confirm the ECR submission status for wage month {mo}?\n\n"
             + ("My records show no employer ECR entry for this month" if f["ecr_status"] is None and f["month"] else f"My records show the ECR status for this month as '{f['ecr_status']}'" if f["ecr_status"] else "I could not see the ECR status for this month")
             + ", which may simply mean it has not been recorded in my view. If it has been submitted, I would be grateful for the acknowledgement or reference; if it is pending, please let me know the expected next step." + tail)
    elif cat == "challan_not_generated":
        sub = f"Request: ECR processing and challan reference for wage month {mo}"; to = "Payroll & PF Officer"
        b = (f"Could you please confirm the processing status of the ECR for wage month {mo} and share the challan/TRRN or payment reference, if one is available?\n\n"
             f"The ECR reference I have is {P(f['ecr_ref'], 'ECR Reference Number')}. " + (f"The challan/TRRN reference entered in my records is {f['trrn']}. " if f["trrn"] else "I do not currently have a challan/TRRN reference ([Reference Number]). ")
             + "If the challan is not yet generated, please let me know what is pending." + tail)
    elif cat == "payment_not_reflected":
        sub = f"Query: PF payment evidence and passbook credit for wage month {mo}"; to = "Payroll & PF Officer"
        b = (f"I am following up on the PF payment for wage month {mo}.\n\n"
             f"My records show the payment status as {P(f['pay_status'], 'Payment Status')}, and I have not been able to confirm a matching credit in my passbook ({P(inr_money(f['posted']), 'Passbook Amount, if available')}). "
             "Could you please share the payment reference and date, and confirm which wage month it covers? I understand passbook posting can lag behind payment." + tail)
    elif cat == "identity_mismatch":
        sub = "Request: review of personal details in PF records"; to = "HR Team"
        b = (f"I noticed that the following detail(s) may differ between my records and the employer's records: {P(f.get('fields'), 'Field Name, e.g. name or date of birth')}.\n\n"
             "Could you please review what is held on your side against my original documents and let me know the process and any reference for a correction, if one is needed? I am not including any identity numbers in this message." + tail)
    elif cat == "claim_transfer_delay":
        sub = f"Query: status of PF claim/transfer {P(ref, 'Reference Number')}"; to = "HR Team"
        b = (f"I am following up on my PF claim/transfer with reference {P(ref, 'Reference Number')}, submitted on [Submission Date]. The latest status I can see is [Current Status] as of [Date].\n\n"
             "Could you please let me know whether anything is needed from the employer side (for example attestation or exit-date confirmation) and share any update you have?" + f"\n\nEmployer: {emp}.")
    elif cat == "employment_overlap":
        sub = "Request: review of employment dates / service period"; to = "HR Team"
        b = (f"I would like to confirm the joining and exit dates held for me at {emp}.\n\n"
             "In my records, [Joining Date] to [Exit Date] at this employer appears to overlap or leave a gap with another employment. I am not assuming an error; could you please confirm the dates in your records, and share my appointment/relieving letter if needed for comparison?" + tail)
    else:
        sub = "PF query: [Subject]"; to = "Support Coordinator"
        b = "I would like help with the following PF issue:\n\n[Describe the issue, with dates and any reference numbers]\n\nCould you please advise on the appropriate next step?" + tail
    return dict(to_role=to, subject=sub, body=f"Dear {to},\n\n{b}{sign}")

def issue_row_out(c, r, detail=False):
    k = c.execute("select name,title from demo_contacts where key=?", (r["contact_key"],)).fetchone()
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    o = dict(id=r["id"], category=r["category"], title=r["title"], status=r["status"], wage_month=r["wage_month"], employer_name=r["employer_name"], next_action=r["next_action"],
             follow_up_date=r["follow_up_date"], created_at=r["created_at"], updated_at=r["updated_at"], contact=(f"{k['name']} — {k['title']} (demo)" if k else None),
             due=bool(r["follow_up_date"] and r["follow_up_date"] <= today and r["status"] not in ACTIVE_NOT))
    if detail:
        o.update(description=r["description"], reference=r["reference"], contact_key=r["contact_key"],
                 notes=[dict(id=n["id"], note=n["note"], at=n["created_at"]) for n in c.execute("select * from issue_notes where issue_id=? order by id desc", (r["id"],))],
                 events=[dict(event=e["event"], from_status=e["from_status"], to_status=e["to_status"], detail=e["detail"], at=e["at"]) for e in c.execute("select * from issue_events where issue_id=? order by id desc", (r["id"],))])
    return o

def notify_issue(c, uid, issue_id, sig, msg):
    if c.execute("select 1 from notifications where user_id=? and issue_id=? and sig=?", (uid, issue_id, sig)).fetchone(): return
    c.execute("insert into notifications(user_id,message,sig,created_at,issue_id) values(?,?,?,?,?)", (uid, msg, sig, now(), issue_id))

def issue_event(c, iid, actor, event, fr=None, to=None, detail=None):
    c.execute("insert into issue_events(issue_id,actor,event,from_status,to_status,detail,at) values(?,?,?,?,?,?,?)", (iid, actor, event, fr, to, detail, now()))
    return c.execute("select last_insert_rowid()").fetchone()[0]

def valid_date(v, label):
    if v in (None, ""): return None
    try: datetime.strptime(str(v), "%Y-%m-%d")
    except Exception: raise Bad(f"{label} must be a date (YYYY-MM-DD)")
    if not ("2000-01-01" <= v <= "2100-12-31"): raise Bad(f"{label} is out of range")
    return v

def own_issue(c, user, iid):
    r = c.execute("select * from issues where id=? and user_id=?", (iid, user["id"])).fetchone()
    if not r: raise Bad("Not found.", 404)
    return r

def issues_api(c, user, method, path, body):
    need(user, "employee")
    prof = c.execute("select * from employee_profiles where user_id=?", (user["id"],)).fetchone(); who = f"employee:{user['id']}"
    if path == "/api/assistant/context":
        rows = []
        for r in c.execute(DETAIL + " order by x.month desc", (prof["id"],)):
            rows.append(dict(id=r["id"], label=f"{r['employer_name']} — {r['month']}", employer_name=r["employer_name"], month=r["month"], classification=r["classification"], tags=rtags(r)))
        return 200, dict(categories=[dict(key=k, title=t, blurb=b, icon=i) for k, t, b, i in CATS], records=rows, grievance_url=grievance_url(),
                         contacts=[contact_out(c, k[0]) for k in DEMO_CONTACTS], user_name=user["name"], demo_org=DEMO_ORG,
                         employers=sorted({e["employer_name"] for e in c.execute("select employer_name from employments where employee_id=?", (prof["id"],))})), None
    if path == "/api/assistant/guidance" and method == "POST":
        cat = body.get("category")
        if cat not in GUIDE: raise Bad("Choose an issue category.")
        g = GUIDE[cat]; f, lines, r = issue_facts(c, prof, user, cat, body)
        ref = text_in(body.get("reference"), "Reference", 40, strict=False)
        flagged = bool(r and cat in rtags(r)) or (cat == "identity_mismatch" and "fields" in f)
        emp_names = {e["employer_name"] for e in c.execute("select employer_name from employments where employee_id=?", (prof["id"],))}
        return 200, dict(category=cat, title=CAT_TITLE[cat], explanation=g["explain"], severity=("Follow-up suggested" if flagged else g["base"]), facts=lines, steps=g["steps"], documents=g["docs"],
                         contact=contact_out(c, g["contact"]), contact_why=g["why"], also_consider=[contact_out(c, k) for k in g["also"]],
                         contact_notice=("These are SAMPLE / DEMO contacts for " + DEMO_ORG + ". " + ("Your employer is " + (f["employer"] or ", ".join(sorted(emp_names)) or "not set") + ", not " + DEMO_ORG + "; contact the corresponding department at your own employer, or have an authorized contact configured for your organization." if DEMO_ORG not in (emp_names | {f["employer"]}) else "")),
                         message=build_message(cat, f, ref), next_action=g["next_action"],
                         grievance=dict(url=grievance_url(), label="Open EPFiGMS (official EPFO grievance portal)", note="Use this after the employer-side steps, where appropriate. It opens an external site; opening it does not submit a grievance and Provident360 cannot tell whether you filed one."),
                         needs_description=(cat == "other"), allows_reference=(cat in ("claim_transfer_delay", "challan_not_generated", "payment_not_reflected"))), None
    if path == "/api/issues" and method == "GET":
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        for r in c.execute("select * from issues where user_id=? and follow_up_date is not null and follow_up_date<=? and status not in ('Resolved','Closed')", (user["id"], today)).fetchall():
            notify_issue(c, user["id"], r["id"], "followup:" + r["follow_up_date"], f"Follow-up due for your tracked issue: {r['title']}. Open the Issue Resolution & Contact Assistant to review it.")
        c.commit()
        return 200, dict(issues=[issue_row_out(c, r) for r in c.execute("select * from issues where user_id=? order by (status in ('Resolved','Closed')), updated_at desc, id desc", (user["id"],))], statuses=list(ISSUE_STATUS)), None
    if path == "/api/issues" and method == "POST":
        cat = body.get("category")
        if cat not in GUIDE: raise Bad("Choose an issue category.")
        desc = text_in(body.get("description"), "Description", 1000, req=(cat == "other"))
        ref = text_in(body.get("reference"), "Reference", 40, strict=False)
        fu = valid_date(body.get("follow_up_date"), "Follow-up date"); f, _, r = issue_facts(c, prof, user, cat, body)
        eid, month, org = (r["employment_id"], r["month"], r["employer_name"]) if r else (None, None, None)
        if not r and body.get("wage_month"):
            if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", str(body["wage_month"])): raise Bad("wage month must look like 2024-03")
            month = body["wage_month"]
        g = GUIDE[cat]; title = CAT_TITLE[cat] + (f" — {month}" if month else "")
        dk = f"{cat}|{eid or 0}|{month or ''}" if cat != "other" else "other|" + norm(desc)[:80]
        if body.get("create_another") not in (True, "true"):
            dup = c.execute("select * from issues where user_id=? and (dedupe_key=? or substr(dedupe_key,1,?)=?) and status not in ('Resolved','Closed') order by id limit 1", (user["id"], dk, len(dk) + 1, dk + "|")).fetchone()
            if dup: return 200, dict(duplicate=True, issue=issue_row_out(c, dup), message="You are already tracking this issue. Open it, or choose 'Create another' to save a separate one."), None
        else: dk += "|" + secrets.token_hex(4)
        try:
            iid = c.execute("insert into issues(user_id,employee_id,category,title,description,employment_id,reconciliation_id,wage_month,employer_name,reference,contact_key,next_action,follow_up_date,status,dedupe_key,created_at,updated_at) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (user["id"], prof["id"], cat, title, desc, eid, r["id"] if r else None, month, org, ref, g["contact"], g["next_action"], fu, "Open", dk, now(), now())).lastrowid
        except sqlite3.IntegrityError: c.rollback(); raise Bad("You are already tracking this issue.", 409)
        issue_event(c, iid, who, "created", None, "Open", "Saved in Provident360 only; nothing was sent to anyone.")
        notify_issue(c, user["id"], iid, "created", f"Issue saved to My Tracking: {title}. This only saves it inside Provident360; no email was sent and no grievance was filed.")
        audit(c, who, "issue_created", detail=f"issue {iid}"); c.commit()
        return 200, dict(duplicate=False, issue=issue_row_out(c, own_issue(c, user, iid), True)), None
    m = re.fullmatch(r"/api/issues/(\d+)(?:/(note|status|plan))?", path)
    if m:
        iid, act = int(m.group(1)), m.group(2); r = own_issue(c, user, iid)
        if act is None and method == "GET": return 200, dict(issue=issue_row_out(c, r, True), statuses=list(ISSUE_STATUS)), None
        if method != "POST": raise Bad("Not found.", 404)
        if act == "note":
            n = text_in(body.get("note"), "Note", 1000, req=True)
            c.execute("insert into issue_notes(issue_id,user_id,note,created_at) values(?,?,?,?)", (iid, user["id"], n, now()))
            c.execute("update issues set updated_at=? where id=?", (now(), iid)); issue_event(c, iid, who, "note_added")
        elif act == "plan":
            na = text_in(body.get("next_action"), "Next action", 200); fu = valid_date(body.get("follow_up_date"), "Follow-up date")
            c.execute("update issues set next_action=coalesce(?,next_action), follow_up_date=?, updated_at=? where id=?", (na, fu, now(), iid)); issue_event(c, iid, who, "plan_updated", detail="next action / follow-up date")
        elif act == "status":
            st = body.get("status")
            if st not in ISSUE_STATUS: raise Bad("Status must be one of: " + ", ".join(ISSUE_STATUS))
            if st == r["status"]: return 200, dict(issue=issue_row_out(c, r, True), unchanged=True), None      # no event, no notification
            if st == "Resolved" and body.get("confirm") not in (True, "true", "on"): raise Bad("Please confirm that the issue is resolved before marking it resolved.")
            c.execute("update issues set status=?, updated_at=? where id=?", (st, now(), iid))
            ev = issue_event(c, iid, who, "status_changed", r["status"], st)
            notify_issue(c, user["id"], iid, f"status:{ev}", f"Status of your tracked issue '{r['title']}' changed to {st}. Saved inside Provident360 only.")
            audit(c, who, "issue_status_changed", detail=f"issue {iid}: {r['status']} -> {st}")
        else: raise Bad("Not found.", 404)
        c.commit(); return 200, dict(issue=issue_row_out(c, own_issue(c, user, iid), True)), None
    raise Bad("Not found.", 404)

# ---------- API ----------
def need(user, role):
    if not user: raise Bad("Please sign in.", 401)
    if user["role"] != role: raise Bad("This area is not available for your role.", 403)

def start_session(c, uid):
    tok = secrets.token_urlsafe(32); c.execute("insert into sessions values(?,?)", (tok, uid)); c.commit()
    return {"Set-Cookie": f"p360={tok}; HttpOnly; SameSite=Strict; Path=/" + ("; Secure" if os.environ.get("PROVIDENT360_HTTPS") else "")}

def pub(u): return {"id": u["id"], "name": u["name"], "email": u["email"], "role": u["role"]}

def register(c, b):
    role = b.get("role"); email = (b.get("email") or "").strip().lower(); name = clean(b, dict(name=(S, 1)))["name"]
    if role not in ("employee", "employer"): raise Bad("Choose a role.")
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email): raise Bad("Enter a valid email.")
    if len(b.get("password") or "") < 8: raise Bad("Password must be at least 8 characters.")
    try:
        uid = c.execute("insert into users(email,name,role,pw) values(?,?,?,?)", (email, name, role, hp(b["password"]))).lastrowid
        if role == "employer":
            o = clean(b, dict(org=(S, 1), establishment_id=(S, 0)))
            c.execute("insert into employers(user_id,name,establishment_id) values(?,?,?)", (uid, o["org"], o["establishment_id"]))
        else:
            o = clean(b, dict(demo_emp_id=(S, 0), uan=(S, 0)))
            c.execute("insert into employee_profiles(user_id,demo_emp_id,uan) values(?,?,?)", (uid, o["demo_emp_id"], o["uan"]))
    except sqlite3.IntegrityError: c.rollback(); raise Bad("That email or establishment ID is already registered.", 409)
    return 200, {"user": pub(c.execute("select * from users where id=?", (uid,)).fetchone())}, start_session(c, uid)

DETAIL = """select x.*, e.employer_name, e.pf_member_id, r.ecr_status, r.ecr_date, r.ecr_ref, r.trrn, r.pay_status, r.pay_date,
 r.emp_epf, r.er_epf, r.eps, r.updated_at r_updated from reconciliations x join employments e on e.id=x.employment_id
 left join employer_records r on r.id=x.employer_record_id where x.employee_id=?"""

def api(c, method, path, body, cookie=""):
    tok = next((p.strip()[5:] for p in cookie.split(";") if p.strip().startswith("p360=")), None)
    user = c.execute("select u.* from sessions s join users u on u.id=s.user_id where s.token=?", (tok,)).fetchone() if tok else None
    if path.startswith(("/api/identity/", "/api/notifications")): return identity_api(c, user, method, path, body)
    if path.startswith(("/api/assistant/", "/api/issues")): return issues_api(c, user, method, path, body)
    if path.startswith("/api/uploads"): return uploads_api(c, user, method, path, body)
    if path == "/api/register" and method == "POST": return register(c, body)
    if path == "/api/login" and method == "POST":
        u = c.execute("select * from users where email=?", ((body.get("email") or "").strip().lower(),)).fetchone()
        if not u or not chk(body.get("password") or "", u["pw"]): raise Bad("Email or password is incorrect.", 401)
        return 200, {"user": pub(u)}, start_session(c, u["id"])
    if path == "/api/logout" and method == "POST":
        c.execute("delete from sessions where token=?", (tok,)); c.commit(); return 200, {"ok": True}, {"Set-Cookie": "p360=; Max-Age=0; Path=/"}
    if path == "/api/me": need(user, user["role"] if user else "x"); return 200, {"user": pub(user)}, None
    if path.startswith("/api/employee/"):
        need(user, "employee"); prof = c.execute("select * from employee_profiles where user_id=?", (user["id"],)).fetchone()
        if path == "/api/employee/employments" and method == "POST": save_employment(c, prof, body); return 200, {"ok": True}, None
        if path == "/api/employee/records" and method == "POST": save_employee_record(c, prof, body); return 200, {"ok": True}, None
        if path == "/api/employee/dashboard":
            emps = [dict(r, pf_masked=mask(r["pf_member_id"])) for r in c.execute("select * from employments where employee_id=? order by joining", (prof["id"],))]
            for e in emps: e.pop("pf_member_id")
            rows = [dict(r, pf_member_id=mask(r["pf_member_id"])) for r in c.execute(DETAIL + " order by x.month desc", (prof["id"],))]
            return 200, {"profile": dict(prof), "employments": emps, "rows": rows}, None
        if path.startswith("/api/employee/detail/"):
            rows = c.execute(DETAIL + " and x.id=?", (prof["id"], int(path.rsplit("/", 1)[1]))).fetchall()
            if not rows: raise Bad("Not found.", 404)
            return 200, {"row": dict(rows[0], pf_member_id=mask(rows[0]["pf_member_id"]))}, None
    if path.startswith("/api/employer/"):
        need(user, "employer"); emp = c.execute("select * from employers where user_id=?", (user["id"],)).fetchone()
        if path == "/api/employer/records" and method == "POST":
            save_employer_record(c, emp, body, int(body["id"]) if body.get("id") else None); return 200, {"ok": True}, None
        if path == "/api/employer/dashboard":
            recs = [dict(r) for r in c.execute("select * from employer_records where employer_id=? order by month desc,id desc", (emp["id"],))]
            for r in recs:
                m = c.execute("select classification from reconciliations where employer_record_id=?", (r["id"],)).fetchall()
                r["match"] = "Not matched to an employee account" if not m else "Matched"
                r["review"] = any(x[0] in ("Potential overlap", "Duplicate record", "Needs review") for x in m) or len(m) > 1
            return 200, {"employer": dict(emp), "records": recs}, None
        if path.startswith("/api/employer/history/"):
            rid = int(path.rsplit("/", 1)[1])
            if not c.execute("select 1 from employer_records where id=? and employer_id=?", (rid, emp["id"])).fetchone(): raise Bad("Not found.", 404)
            return 200, {"history": [dict(h, snapshot=json.loads(h["snapshot"])) for h in c.execute("select * from record_history where record_id=? order by id desc", (rid,))]}, None
    raise Bad("Not found.", 404)

# ---------- demo data (synthetic) ----------
PF_A, PF_B = "DEMO-TN-A0001", "DEMO-KA-B0002"
def seed(c):
    if c.execute("select 1 from users").fetchone(): return
    def mk(email, name, role): return c.execute("insert into users(email,name,role,pw) values(?,?,?,?)", (email, name, role, hp("demo1234"))).lastrowid
    u = mk("asha@demo.test", "Asha Demo", "employee")
    c.execute("insert into employee_profiles(user_id,demo_emp_id,uan) values(?,?,?)", (u, "DEMO-EMP-001", "DEMO-UAN-100000001"))
    prof = c.execute("select * from employee_profiles").fetchone()
    save_employment(c, prof, dict(employer_name="Sunrise Textiles (Demo)", establishment_id="DEMOTN0001", pf_member_id=PF_A, joining="2022-04-01", exit_date="2024-03-15", status="Previous"))
    save_employment(c, prof, dict(employer_name="Lakeview Tech (Demo)", establishment_id="DEMOKA0002", pf_member_id=PF_B, joining="2024-03-01", status="Current"))
    save_employee_record(c, prof, dict(employment_id=1, month="2024-01", pf_wages=15000, emp_contrib=1800, passbook_emp=1800))
    save_employee_record(c, prof, dict(employment_id=2, month="2024-04", pf_wages=40000, emp_contrib=1800))
    for em, org, est in (("hr@sunrise.demo.test", "Sunrise Textiles (Demo)", "DEMOTN0001"), ("hr@lakeview.demo.test", "Lakeview Tech (Demo)", "DEMOKA0002")):
        uid = mk(em, org + " HR", "employer"); c.execute("insert into employers(user_id,name,establishment_id) values(?,?,?)", (uid, org, est))
    e1, e2 = c.execute("select * from employers order by id").fetchall()
    base = dict(employee_name="Asha Demo", employee_ref="DEMO-EMP-001", pf_wages=15000, emp_epf=1800, er_epf=550, eps=1250, ecr_status="Submitted")
    save_employer_record(c, e1, dict(base, pf_member_id=PF_A, month="2024-01", ecr_date="2024-02-12", ecr_ref="ECR-DEMO-0001", trrn="TRRN-DEMO-01", pay_status="Paid", pay_date="2024-02-14"))
    save_employer_record(c, e1, dict(base, pf_member_id=PF_A, month="2024-02", ecr_date="2024-03-11", ecr_ref="ECR-DEMO-0002", trrn="TRRN-DEMO-02", pay_status="Paid", pay_date="2024-03-13"))
    save_employer_record(c, e1, dict(base, pf_member_id=PF_A, month="2024-03", ecr_date="2024-04-10", ecr_ref="ECR-DEMO-0003", pay_status="Pending"))
    save_employer_record(c, e2, dict(base, pf_member_id=PF_B, month="2024-03", pf_wages=40000, ecr_date="2024-04-12", ecr_ref="ECR-DEMO-0101", pay_status="Pending"))

# ---------- sensitive-image upload protection (OTP / identifier screenshots) ----------
# Every endpoint that accepts an image is listed in UPLOAD_ROUTES and is served by serve_upload(), which is the
# only code path that can create a stored upload. It always runs image_scan.scan_upload() BEFORE anything is written.
PURPOSES = ("claim_support", "employment_document", "other")
UPLOAD_ROUTES = {
    "documents": re.compile(r"/api/documents/upload"),                     # Documents page (incl. claim supporting images)
    "kyc": re.compile(r"/api/identity/kyc/upload"),                        # KYC image on Identity Verification
    "issue_attachment": re.compile(r"/api/issues/(\d+)/attachments"),      # Issue Assistant attachments
}
def uploads_dir():
    d = Path(os.environ.get("PROVIDENT360_UPLOADS", str(ROOT / "uploads_private")))
    d.mkdir(parents=True, exist_ok=True)
    try: os.chmod(d, 0o700)
    except OSError: pass
    return d
def _env_int(name, default):
    try: return int(os.environ.get(name, default))
    except ValueError: return default
def fail_closed(route):
    """True = refuse images that cannot be verified (OCR down, timeout, ambiguous). Default and recommended."""
    v = os.environ.get("P360_FAIL_CLOSED_" + route.upper(), os.environ.get("P360_FAIL_CLOSED", "1")).strip().lower()
    return image_scan is None or v not in ("0", "false", "no", "off")

_RATE = defaultdict(deque); _RATE_LOCK = threading.Lock()
def rate_ok(uid):
    """Counts every attempt (blocked or not) so the scanner cannot be probed as an oracle."""
    limit, t = _env_int("P360_UPLOADS_PER_MINUTE", 10), _time.monotonic()
    with _RATE_LOCK:
        q = _RATE[uid]
        while q and t - q[0] > 60: q.popleft()
        if len(q) >= limit: return False
        q.append(t); return True

def session_user(c, cookie):
    tok = next((p.strip()[5:] for p in (cookie or "").split(";") if p.strip().startswith("p360=")), None)
    return c.execute("select u.* from sessions s join users u on u.id=s.user_id where s.token=?", (tok,)).fetchone() if tok else None

def upload_match(method, path):
    if method == "GET":
        m = re.fullmatch(r"/api/uploads/(\d+)/file", path)
        return ("download", int(m.group(1))) if m else None
    if method == "POST":
        for name, rx in UPLOAD_ROUTES.items():
            m = rx.fullmatch(path)
            if m: return (name, m)
    return None

TITLE = "Sensitive information detected"
ACTIONS = [dict(id="redact", label="Remove or permanently redact the sensitive part and upload again"), dict(id="choose", label="Choose a different document"), dict(id="cancel", label="Cancel upload")]
LABELS = dict(aadhaar="an Aadhaar number", pan="a PAN", uan="a UAN", bank_account="bank account details", card="a card number", credential="a PIN or password")
def refusal(res):
    """Fixed, safe wording only. Never includes OCR text or any detected value."""
    cats = list(res.categories)
    if res.status == "blocked" and "otp" in cats:
        title, msg = TITLE, ("This screenshot may contain a one-time password (OTP) or verification code. For your security, Provident360 has blocked this image from being saved. "
                             "Never share an OTP with anyone, including support staff.")
    elif res.status == "blocked":
        what = ", ".join(LABELS.get(x, x) for x in cats)
        title, msg = TITLE, f"This image may contain {what}. For your security, Provident360 has blocked it from being saved. Remove or permanently redact it and upload again."
    elif res.status == "uncertain":
        title, msg = "This image could not be verified as safe", ("This image mentions a verification code, and Provident360 could not confirm that no code is visible. It was not saved. "
                                                                  "Please upload a version where any code is permanently redacted.")
    elif res.status == "unavailable":
        title, msg = "This image could not be checked right now", "Provident360 could not safely scan this image, so it was not saved. Please try again in a moment, or upload a redacted image."
    else:
        title, msg = "This file cannot be uploaded", {
            "EMPTY_FILE": "The file is empty.", "TOO_LARGE": "The file is too large (limit 5 MB).", "TOO_LARGE_DIMENSIONS": "The image dimensions are too large.",
            "UNSUPPORTED_TYPE": "Only PNG, JPEG or WebP images are accepted.", "TYPE_MISMATCH": "The file content does not match an accepted image type.",
            "TOO_SMALL": "The image is too small to be a document.", "ANIMATED_NOT_ALLOWED": "Animated images are not accepted.",
            "MALFORMED_IMAGE": "The file is not a valid image."}.get(res.reason, "The file could not be accepted.")
    out = dict(error=msg, blocked=res.status in ("blocked", "uncertain", "unavailable"), title=title, message=msg, code=res.reason, categories=cats)
    if out["blocked"]: out["actions"] = ACTIONS
    if res.status == "unavailable": out["retry"] = True
    return res.http, out

def read_body(h, n):
    h.connection.settimeout(_env_int("P360_UPLOAD_READ_TIMEOUT", 30))
    buf = bytearray()
    while len(buf) < n:
        chunk = h.rfile.read(min(65536, n - len(buf)))
        if not chunk: break
        buf += chunk
    return bytes(buf)

def store_upload(c, user, route, purpose, issue_id, data, mime):
    """Write an already-scanned, sanitised image, encrypted, to the private upload directory (temp name -> atomic rename)."""
    from cryptography.fernet import Fernet as F
    key = secrets.token_hex(24); d = uploads_dir(); tmp = d / f".tmp-{secrets.token_hex(8)}"; final = d / (key + ".bin")
    try:
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(F(_master()).encrypt(data)); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, final)
        uid = c.execute("insert into uploads(user_id,route,purpose,issue_id,file_key,mime,size,created_at) values(?,?,?,?,?,?,?,?)", (user["id"], route, purpose, issue_id, key, mime, len(data), now())).lastrowid
        audit(c, f"{user['role']}:{user['id']}", "upload_accepted", detail=f"route={route}; upload {uid}"); c.commit()
        return uid
    except BaseException:
        c.rollback()
        for p in (tmp, final):
            try: os.unlink(p)
            except OSError: pass
        raise

def upload_out(r): return dict(id=r["id"], route=r["route"], purpose=r["purpose"], issue_id=r["issue_id"], mime=r["mime"], size=r["size"], created_at=r["created_at"])

def uploads_api(c, user, method, path, body):
    if not user: raise Bad("Please sign in.", 401)
    if path == "/api/uploads" and method == "GET":
        return 200, {"uploads": [upload_out(r) for r in c.execute("select * from uploads where user_id=? order by id desc", (user["id"],))]}, None
    m = re.fullmatch(r"/api/uploads/(\d+)/delete", path)
    if m and method == "POST":
        r = c.execute("select * from uploads where id=? and user_id=?", (int(m.group(1)), user["id"])).fetchone()
        if not r: raise Bad("Not found.", 404)
        c.execute("delete from uploads where id=?", (r["id"],)); audit(c, f"{user['role']}:{user['id']}", "upload_deleted", detail=f"upload {r['id']}"); c.commit()
        try: os.unlink(uploads_dir() / (r["file_key"] + ".bin"))
        except OSError: pass
        return 200, {"ok": True}, None
    raise Bad("Not found.", 404)

def send_download(h, c, user, uid):
    from cryptography.fernet import Fernet as F
    r = c.execute("select * from uploads where id=? and user_id=?", (uid, user["id"])).fetchone()      # owner only
    if not r: return h.out(404, {"error": "Not found."})
    try: data = F(_master()).decrypt((uploads_dir() / (r["file_key"] + ".bin")).read_bytes())
    except Exception: return h.out(404, {"error": "Not found."})
    h.out(200, data, r["mime"], {"Content-Disposition": f'inline; filename="upload-{r["id"]}.{"jpg" if r["mime"] == "image/jpeg" else r["mime"].split("/")[1]}"'})

def serve_upload(h, method, path, hit, query):
    name, arg = hit; c = db()
    try:
        user = session_user(c, h.headers.get("Cookie", ""))
        if not user: return h.out(401, {"error": "Please sign in."})                    # authenticate before touching the body
        if name == "download": return send_download(h, c, user, arg)
        if h.headers.get("X-P360-Upload") != "1": return h.out(403, {"error": "Invalid upload request."})        # CSRF: custom header forces a CORS preflight
        origin = h.headers.get("Origin")
        if origin and urlsplit(origin).netloc != h.headers.get("Host"): return h.out(403, {"error": "Invalid upload request."})
        issue_id, purpose = None, None
        if name == "issue_attachment":
            need(user, "employee"); issue_id = own_issue(c, user, int(arg.group(1)))["id"]; purpose = "issue"
        elif name == "kyc": purpose = "kyc"
        else:
            purpose = (query.get("purpose") or ["other"])[0]
            if purpose not in PURPOSES: return h.out(400, {"error": "Choose a valid document purpose."})
        if c.execute("select count(*) from uploads where user_id=?", (user["id"],)).fetchone()[0] >= _env_int("P360_MAX_UPLOADS_PER_USER", 200):
            return h.out(409, {"error": "You have reached the upload limit. Delete an older upload first."})
        if not rate_ok(user["id"]): return h.out(429, {"error": "Too many upload attempts. Please wait a minute and try again."}, hdr={"Retry-After": "60"})
        if image_scan is None: return h.out(*refusal(image_scan_missing()))
        raw_len = h.headers.get("Content-Length")
        if raw_len is None or not raw_len.isdigit(): return h.out(411, {"error": "Content-Length is required."})
        n = int(raw_len)
        if n == 0: return h.out(*refusal(image_scan.ScanResult("invalid", "EMPTY_FILE", http=400)))
        if n > image_scan.MAX_BYTES() + 4096:                                          # refuse without reading the body
            h.close_connection = True; return h.out(*refusal(image_scan.ScanResult("invalid", "TOO_LARGE", http=413)))
        try: raw = read_body(h, n)
        except OSError: h.close_connection = True; return h.out(408, {"error": "Upload timed out. Nothing was saved."})
        if len(raw) != n: return h.out(400, {"error": "Incomplete upload. Nothing was saved."})
        res = image_scan.scan_upload(raw, fail_closed=fail_closed(name)); raw = None   # scan happens fully in memory, before any write
        who = f"{user['role']}:{user['id']}"
        if not res.accepted:
            audit(c, who, "upload_blocked" if res.status in ("blocked", "uncertain") else "upload_rejected", detail=f"route={name}; outcome={res.status}; reason={res.reason}; categories={','.join(res.categories) or '-'}"); c.commit()
            return h.out(*refusal(res))
        uid = store_upload(c, user, name, purpose, issue_id, res.data, res.mime)
        return h.out(200, {"ok": True, "verified": res.verified, "upload": upload_out(c.execute("select * from uploads where id=?", (uid,)).fetchone())})
    except Bad as e: return h.out(e.code, {"error": str(e)})
    except Exception: return h.out(500, {"error": "The upload could not be processed. Nothing was saved."})     # never echo exception text
    finally: c.close()

def image_scan_missing():
    class R: status, reason, categories, http = "unavailable", "SCANNER_UNAVAILABLE", (), 503
    return R

# ---------- HTTP ----------
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def out(self, code, data, ctype="application/json", hdr=None):
        b = data if isinstance(data, bytes) else json.dumps(data).encode()
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(b)))
        self.send_header("X-Content-Type-Options", "nosniff"); self.send_header("Referrer-Policy", "no-referrer"); self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-ancestors 'none'"); self.send_header("Cache-Control", "no-store")
        for k, v in (hdr or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(b)
    def go(self, method):
        path = self.path.split("?")[0]
        hit = upload_match(method, path) if path.startswith("/api/") else None
        if hit: return serve_upload(self, method, path, hit, parse_qs(urlsplit(self.path).query))
        if not path.startswith("/api/"):
            return self.out(200, (ROOT / "static" / "index.html").read_bytes(), "text/html; charset=utf-8")
        c = db()
        try:
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(min(n, 100000)) or b"{}") if method == "POST" else {}
            code, obj, hdr = api(c, method, path, body, self.headers.get("Cookie", ""))
        except Bad as e: code, obj, hdr = e.code, {"error": str(e)}, None
        except (ValueError, KeyError): code, obj, hdr = 400, {"error": "Invalid request."}, None
        finally: pass
        c.close(); self.out(code, obj, hdr=hdr)
    do_GET = lambda s: s.go("GET")
    do_POST = lambda s: s.go("POST")

if __name__ == "__main__":
    init(); port = int(os.environ.get("PORT", 8000))
    if image_scan is None or not image_scan.ocr_available():
        print("WARNING: image upload scanning is unavailable (needs Pillow and the tesseract OCR program). Image uploads will be refused until it is installed; see UPLOAD_PROTECTION.md.")
    print(f"Provident360 running at http://localhost:{port}  (demo mode, synthetic data)")
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()