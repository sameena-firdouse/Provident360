"""Image validation, sanitising and OCR-based sensitive-content scanning for Provident360 uploads.

Everything happens in memory. OCR runs the local `tesseract` binary with the image piped through stdin, so no
temporary file is created. Nothing here ever returns, logs or stores recognised text: callers only receive a
ScanResult holding a status, a reason code and category names.
"""
import io, os, shutil, subprocess, threading, time
from dataclasses import dataclass, field

from PIL import Image, ImageOps, UnidentifiedImageError

import sensitive_detect as sd

# ---------- limits (override with environment variables) ----------
def _int(name, default):
    try: return int(os.environ.get(name, default))
    except ValueError: return default
MAX_BYTES = lambda: _int("P360_MAX_IMAGE_BYTES", 5 * 1024 * 1024)
MAX_PIXELS = lambda: _int("P360_MAX_IMAGE_PIXELS", 25_000_000)
MAX_SIDE = lambda: _int("P360_MAX_IMAGE_SIDE", 10_000)
MIN_SIDE = 24
OCR_TIMEOUT = lambda: _int("P360_OCR_TIMEOUT", 25)          # seconds for the whole scan
OCR_CONCURRENCY = lambda: max(1, _int("P360_OCR_CONCURRENCY", 2))

_slots = None; _slots_n = 0; _slot_lock = threading.Lock()
def _semaphore():
    global _slots, _slots_n
    with _slot_lock:
        if _slots is None or _slots_n != OCR_CONCURRENCY():
            _slots_n = OCR_CONCURRENCY(); _slots = threading.BoundedSemaphore(_slots_n)
        return _slots

# ---------- result ----------
CLEAN, BLOCKED, UNCERTAIN, INVALID, UNAVAILABLE = "clean", "blocked", "uncertain", "invalid", "unavailable"

@dataclass
class ScanResult:
    status: str
    reason: str                      # short machine code, safe to log / return
    categories: tuple = ()           # category names only, never values
    data: bytes = b""                # sanitised image bytes (only when accepted)
    mime: str = ""
    verified: bool = False           # False when accepted on a fail-open route without a successful scan
    http: int = 200
    extra: dict = field(default_factory=dict)
    @property
    def accepted(self): return self.status == CLEAN

def _bad(reason, http=400): return ScanResult(INVALID, reason, http=http)

# ---------- validation + sanitising ----------
def sniff(raw):
    if raw[:8] == b"\x89PNG\r\n\x1a\n": return "PNG", "image/png"
    if raw[:3] == b"\xff\xd8\xff": return "JPEG", "image/jpeg"
    if raw[:4] == b"RIFF" and raw[8:12] == b"WEBP": return "WEBP", "image/webp"
    return None, None

def validate_and_sanitise(raw):
    """Return (ScanResult-or-None, pil_image, fmt). On failure the first item is an INVALID ScanResult."""
    if not raw: return _bad("EMPTY_FILE"), None, None
    if len(raw) > MAX_BYTES(): return _bad("TOO_LARGE", 413), None, None
    fmt, _ = sniff(raw)
    if not fmt: return _bad("UNSUPPORTED_TYPE", 415), None, None          # client MIME and extension are never trusted
    Image.MAX_IMAGE_PIXELS = MAX_PIXELS()
    try:
        with Image.open(io.BytesIO(raw)) as probe:
            if probe.format != fmt: return _bad("TYPE_MISMATCH", 415), None, None
            w, h = probe.size
            if w < MIN_SIDE or h < MIN_SIDE: return _bad("TOO_SMALL"), None, None
            if w > MAX_SIDE() or h > MAX_SIDE() or w * h > MAX_PIXELS(): return _bad("TOO_LARGE_DIMENSIONS", 413), None, None
            if getattr(probe, "n_frames", 1) > 1: return _bad("ANIMATED_NOT_ALLOWED", 415), None, None
            probe.verify()
        with Image.open(io.BytesIO(raw)) as im:
            im.load()
            im = ImageOps.exif_transpose(im)                     # honour rotation, then drop all metadata below
            if im.mode in ("RGBA", "LA", "P") or "transparency" in im.info:
                im = im.convert("RGBA"); bg = Image.new("RGB", im.size, (255, 255, 255)); bg.paste(im, mask=im.getchannel("A")); flat = bg
            else:
                flat = im.convert("RGB")
            clean = Image.new("RGB", flat.size); clean.paste(flat)   # fresh image: no EXIF, ICC, text chunks or XMP
    except (UnidentifiedImageError, Image.DecompressionBombError, Image.DecompressionBombWarning):
        return _bad("MALFORMED_IMAGE"), None, None
    except (OSError, ValueError, SyntaxError, EOFError, MemoryError):
        return _bad("MALFORMED_IMAGE"), None, None
    return None, clean, fmt

def encode_clean(img, fmt):
    buf = io.BytesIO()
    if fmt == "JPEG": img.save(buf, "JPEG", quality=92, optimize=True); return buf.getvalue(), "image/jpeg"
    img.save(buf, "PNG", optimize=True); return buf.getvalue(), "image/png"

# ---------- OCR ----------
class OCRUnavailable(Exception): pass
class OCRTimeout(Exception): pass

def tesseract_path():
    return os.environ.get("P360_TESSERACT") or shutil.which("tesseract")
def ocr_available():
    p = tesseract_path()
    if not p: return False
    try: return subprocess.run([p, "--version"], capture_output=True, timeout=10).returncode == 0
    except Exception: return False

def _prep(img, invert=False, rotate=0):
    g = ImageOps.autocontrast(img.convert("L"))
    if rotate: g = g.rotate(rotate, expand=True)
    w, h = g.size
    scale = 1.0
    if w < 1000: scale = min(3.0, 1000 / w)                    # small screenshots OCR much better enlarged
    elif max(w, h) > 3200: scale = 3200 / max(w, h)
    if abs(scale - 1) > 0.05: g = g.resize((max(1, int(w * scale)), max(1, int(h * scale))), Image.LANCZOS)
    if invert: g = ImageOps.invert(g)
    # tesseract copes poorly with edge-to-edge text: add a small border
    return ImageOps.expand(g, border=20, fill=255 if not invert else 0)

def _ocr(img, psm, deadline):
    left = deadline - time.monotonic()
    if left <= 0.5: raise OCRTimeout()
    exe = tesseract_path()
    if not exe: raise OCRUnavailable()
    buf = io.BytesIO(); img.save(buf, "PNG")
    env = dict(os.environ, OMP_THREAD_LIMIT="1")
    try:
        p = subprocess.run([exe, "stdin", "stdout", "-l", "eng", "--oem", "1", "--psm", str(psm)], input=buf.getvalue(),
                           capture_output=True, timeout=left, env=env)
    except subprocess.TimeoutExpired: raise OCRTimeout()
    except OSError: raise OCRUnavailable()
    if p.returncode != 0: raise OCRUnavailable()
    return p.stdout.decode("utf-8", "ignore")

def scan_pixels(img, allow=(), deadline=None):
    """OCR several preprocessed variants and return the set of finding categories (names) plus a certain flag map.
    Raises OCRUnavailable / OCRTimeout. Recognised text exists only inside this function."""
    deadline = deadline or time.monotonic() + OCR_TIMEOUT()
    found = {}                       # category -> certain
    def feed(text):
        for f in sd.analyse(text, allow=allow):
            found[f.category] = found.get(f.category, False) or f.certain
    plan = [(dict(), 11), (dict(), 6), (dict(invert=True), 11)]
    def decided(): return any(certain for c, certain in found.items() if c != sd.UNCERTAIN)
    for kw, psm in plan:
        feed(_ocr(_prep(img, **kw), psm, deadline))
        if decided(): return found
    for rot in (90, 270, 180):                                  # sideways / upside-down screenshots; OCR junk must not skip this
        feed(_ocr(_prep(img, rotate=rot), 11, deadline))
        if decided(): break
    if found.get(sd.OTP) or any(certain for certain in found.values()): found.pop(sd.UNCERTAIN, None)
    return found

# ---------- main entry ----------
def scan_upload(raw, *, fail_closed=True, allow=None):
    """Validate, sanitise and scan one uploaded image. The only function routes should call.
    Never writes to disk. Returns ScanResult; `data` is populated only when the upload may be stored."""
    allow = sd.allowed_categories() if allow is None else set(allow)
    bad, img, fmt = validate_and_sanitise(raw)
    if bad: return bad
    sem = _semaphore()
    if not sem.acquire(timeout=10):
        return _unverifiable(img, fmt, "SCANNER_BUSY", fail_closed)
    try:
        found = scan_pixels(img, allow)
    except OCRTimeout: return _unverifiable(img, fmt, "SCAN_TIMEOUT", fail_closed)
    except OCRUnavailable: return _unverifiable(img, fmt, "SCANNER_UNAVAILABLE", fail_closed)
    except Exception: return _unverifiable(img, fmt, "SCAN_ERROR", fail_closed)    # message deliberately not captured
    finally: sem.release()
    certain = tuple(sorted(c for c, ok in found.items() if ok and c != sd.UNCERTAIN))
    if certain:
        return ScanResult(BLOCKED, "OTP_DETECTED" if sd.OTP in certain else "SENSITIVE_DETECTED", certain, http=422)
    if sd.UNCERTAIN in found and fail_closed:
        return ScanResult(UNCERTAIN, "POSSIBLE_OTP_UNVERIFIED", (sd.UNCERTAIN,), http=422)
    data, mime = encode_clean(img, fmt)
    return ScanResult(CLEAN, "CLEAN" if sd.UNCERTAIN not in found else "UNCERTAIN_ALLOWED", (), data, mime, verified=sd.UNCERTAIN not in found)

def _unverifiable(img, fmt, reason, fail_closed):
    if fail_closed: return ScanResult(UNAVAILABLE, reason, http=503)
    data, mime = encode_clean(img, fmt)
    return ScanResult(CLEAN, reason, (), data, mime, verified=False)