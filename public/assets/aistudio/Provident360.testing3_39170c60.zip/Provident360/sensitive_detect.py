"""Sensitive-content detection on plain text (e.g. OCR output). Pure functions, standard library only.

Design rules
- Contextual matching: a bare 6-digit number is NOT treated as an OTP. A code is flagged when it sits near
  OTP / verification-code wording. Wording with no readable code is "uncertain" (safe warning, not silence).
- Findings carry only a category and a confidence. They NEVER carry the matched text, so a finding can be
  returned to a browser or written to an audit log without leaking the secret.
"""
import os, re
from dataclasses import dataclass

# categories
OTP, CREDENTIAL, AADHAAR, PAN, UAN, BANK, CARD, UNCERTAIN = "otp", "credential", "aadhaar", "pan", "uan", "bank_account", "card", "uncertain_otp"
ALL_CATEGORIES = (OTP, CREDENTIAL, AADHAAR, PAN, UAN, BANK, CARD, UNCERTAIN)

@dataclass(frozen=True)
class Finding:
    category: str          # one of ALL_CATEGORIES
    certain: bool          # True = a secret value was located; False = wording only / low confidence

# ---------- configuration ----------
def allowed_categories(extra=()):
    """Categories an operator has chosen to allow, e.g. P360_SCAN_ALLOW=pan,uan. OTP is never allowable."""
    raw = os.environ.get("P360_SCAN_ALLOW", "")
    out = {x.strip() for x in raw.split(",") if x.strip()} | set(extra)
    return (out & set(ALL_CATEGORIES)) - {OTP, CREDENTIAL, UNCERTAIN}

# ---------- text normalisation ----------
_TRANS = str.maketrans({"–": "-", "—": "-", "−": "-", " ": " ", "​": "", "•": "*"})
def normalise(text):
    t = (text or "").translate(_TRANS)
    return re.sub(r"[ \t]+", " ", t)

# OTP wording. OCR often reads 0 as O, so [o0] is accepted in "otp".
_STRONG = re.compile(
    r"\b[o0]\s?t\s?p\b|one[\s-]*time[\s-]*(?:pass(?:word|code)?|pin|code)|\bverification\s+(?:code|pin|number)\b|"
    r"\b(?:authentication|authorization|authorisation|security|confirmation|login|log-in|sign-in|signin|access|activation|reset|transaction)\s+(?:code|pin)\b|"
    r"\b(?:2fa|two[\s-]*factor|2[\s-]*step|two[\s-]*step)\b|\bpass[\s-]?code\b|\bverify\s+(?:your|with)\b|\bsecret\s+code\b", re.I)
# wording that is typical of a code-delivery message but not conclusive on its own
_WEAK = re.compile(
    r"\bdo\s+not\s+share\b|\bdon'?t\s+share\b|\bnever\s+share\b|\bnot\s+share\s+(?:this|it|your)\b|(?:expires?|valid|expiring)\s+(?:in|for|within)\s+\d+\s*(?:min|minute|minutes|mins|sec|seconds|hour|hours)\b|"
    r"\b(?:enter|use)\s+(?:this|the)\s+code\b|\bcode\s+(?:is|:)|\byour\s+code\b|\bverification\b", re.I)
_CODE_WORD = re.compile(r"\bcode\b", re.I)

# a numeric token that could be a code: 4-8 digits, optionally grouped "123 456", "123-456", "12-34-56", "1234 5678"
_GROUPED = r"(?:\d{3}[ -]\d{3}|\d{2}[ -]\d{2}[ -]\d{2}|\d{4}[ -]\d{4}|\d{3}[ -]\d{2,3}|\d{2}[ -]\d{3}|\d{4,8})"
# OCR confusion forms: O/o->0, I/l->1 allowed inside tokens that still contain >=3 true digits
_CAND = re.compile(rf"(?<![\w/.:,@#$-])({_GROUPED}|[0-9OoIl]{{4,8}})(?![\w/:@%]|\.\d|,\d)")
# prefixed codes such as "G-482731" (Google style)
_PREFIXED = re.compile(r"\b[A-Za-z]{1,2}-(\d{4,8})\b")

def _digits(tok):
    return re.sub(r"[ -]", "", tok).translate(str.maketrans("OoIl", "0011"))

def _plausible_code(tok, text, start, end):
    raw = re.sub(r"[ -]", "", tok)
    d = _digits(tok)
    if not d.isdigit() or not 4 <= len(d) <= 8: return False
    if sum(ch.isdigit() for ch in raw) < 3: return False          # mostly letters: a word, not a code
    around = text[max(0, start - 4):start]
    if re.search(r"(?:rs\.?|inr|usd|₹|\$|€|£)\s*$", around, re.I): return False   # money
    after = text[end:end + 3]
    if re.match(r"\s?(?:%|rs|inr|/-)", after, re.I): return False
    if len(d) == 4 and re.fullmatch(r"(?:19|20)\d\d", d): return False                   # a year
    return True

def _find_codes(text):
    out = []
    for m in _CAND.finditer(text):
        if _plausible_code(m.group(1), text, m.start(1), m.end(1)): out.append((m.start(1), m.end(1)))
    for m in _PREFIXED.finditer(text): out.append((m.start(1), m.end(1)))
    return out

def _line_window(text, a, b, before=70, after=120):
    return max(0, a - before), min(len(text), b + after)

def detect_otp(text):
    """Return (found_code, found_wording). Code must be near strong wording (or near weak wording + 'code')."""
    t = normalise(text)
    strong = [m for m in _STRONG.finditer(t)]
    weak = [m for m in _WEAK.finditer(t)]
    codes = _find_codes(t)
    found_code = False
    for s, e in codes:
        for m in strong:
            if (m.start() - 60 <= s <= m.end() + 120) or (m.start() - 60 <= e <= m.end() + 120): found_code = True; break
        if found_code: break
        # weak wording only counts when two independent hints agree (e.g. "code" + "do not share" / "expires in")
        hints = [w for w in weak if w.start() - 120 <= s <= w.end() + 160]
        if len(hints) >= 2 or (hints and _CODE_WORD.search(t[max(0, s - 80):e + 80])): found_code = True; break
    wording = bool(strong) or len(weak) >= 2 or (bool(weak) and bool(_CODE_WORD.search(t)))
    return found_code, wording

# ---------- structured identifiers ----------
_VD = ((0,1,2,3,4,5,6,7,8,9),(1,2,3,4,0,6,7,8,9,5),(2,3,4,0,1,7,8,9,5,6),(3,4,0,1,2,8,9,5,6,7),(4,0,1,2,3,9,5,6,7,8),
       (5,9,8,7,6,0,4,3,2,1),(6,5,9,8,7,1,0,4,3,2),(7,6,5,9,8,2,1,0,4,3),(8,7,6,5,9,3,2,1,0,4),(9,8,7,6,5,4,3,2,1,0))
_VP = ((0,1,2,3,4,5,6,7,8,9),(1,5,7,6,2,8,3,0,9,4),(5,8,0,3,7,9,6,1,4,2),(8,9,1,6,0,4,3,5,2,7),(9,4,5,3,1,2,6,8,7,0),
       (4,2,8,6,5,7,3,9,0,1),(2,7,9,3,8,0,6,4,1,5),(7,0,4,6,9,1,3,2,5,8))
def verhoeff_ok(num):
    c = 0
    for i, ch in enumerate(reversed(num)): c = _VD[c][_VP[i % 8][int(ch)]]
    return c == 0
def luhn_ok(num):
    s = 0
    for i, ch in enumerate(reversed(num)):
        d = int(ch)
        if i % 2: d = d * 2 - 9 if d * 2 > 9 else d * 2
        s += d
    return s % 10 == 0

_AADHAAR = re.compile(r"(?<![\d-])([2-9]\d{3})[ -]?(\d{4})[ -]?(\d{4})(?![\d-])")
_AADHAAR_KW = re.compile(r"\baadh+a+r\b|\buidai\b|\bvid\b|\bvirtual\s+id\b|\benrol", re.I)
_PAN = re.compile(r"(?<![A-Za-z0-9])([A-Z]{3}[ABCFGHLJPTK][A-Z])[ -]?([0-9OIlSB]{4})[ -]?([A-Z])(?![A-Za-z0-9])")
_UAN = re.compile(r"\buan\b[^\d\n]{0,25}(\d{12})\b|\b(\d{12})\b[^\n]{0,15}\buan\b", re.I)
_ACCT_KW = re.compile(r"(?:\ba/?c\b|\bacct?\b|\baccount\s*(?:no|number|num|#)?\b|\bacc\s*no\b|\bcrn\b)[^\d\n]{0,25}(\d{9,18})(?![\d-])", re.I)
_IFSC = re.compile(r"\b[A-Z]{4}0[A-Z0-9]{6}\b")
_ACCT = re.compile(r"(?<![\d-])(\d{9,18})(?![\d-])")
_CARD = re.compile(r"(?<![\d-])((?:\d[ -]?){13,19})(?![\d-])")
_CRED = re.compile(r"\b(?:upi\s*pin|mpin|pin|cvv|cvc)\s*(?:is|=|:)\s*[:=]?\s*(\d{3,8})\b|\b(?:password|passwd|passphrase)\s*(?:is|=|:)\s*[:=]?\s*(\S*\d\S*)", re.I)

def detect_identifiers(text):
    t = normalise(text); found = set()
    for m in _AADHAAR.finditer(t):
        n = "".join(m.groups())
        if verhoeff_ok(n) or _AADHAAR_KW.search(t): found.add(AADHAAR)   # keyword + 12 digits even if OCR broke the checksum
    if _PAN.search(t): found.add(PAN)
    if _UAN.search(t): found.add(UAN)
    if _ACCT_KW.search(t) or (_IFSC.search(t) and _ACCT.search(t)): found.add(BANK)
    for m in _CARD.finditer(t):
        n = re.sub(r"[ -]", "", m.group(1))
        if 13 <= len(n) <= 19 and luhn_ok(n): found.add(CARD)
    if _CRED.search(t): found.add(CREDENTIAL)
    return found

# ---------- public API ----------
def analyse(text, allow=None):
    """Return a list of Finding for the given text. `allow` = categories the caller permits (never OTP)."""
    allow = allowed_categories() if allow is None else (set(allow) - {OTP, CREDENTIAL, UNCERTAIN})
    out = []
    code, wording = detect_otp(text)
    if code: out.append(Finding(OTP, True))
    elif wording: out.append(Finding(UNCERTAIN, False))
    for cat in sorted(detect_identifiers(text)):
        if cat in allow: continue
        out.append(Finding(cat, True))
    return out